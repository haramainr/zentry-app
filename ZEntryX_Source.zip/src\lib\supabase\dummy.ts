export function getDummyClient(role: string = 'Manager') {
  const dummyUser = {
    id: 'dummy-admin-id',
    email: 'admin@zentry.com',
    user_metadata: { full_name: `Akun ${role} (Preview)`, role: role }
  };

  const dummyDataMap: Record<string, any> = {
    users: [
      {
        id: 'dummy-admin-id',
        full_name: `Akun ${role} (Preview)`,
        role: role,
        subscription_status: 'Active',
        subscription_end_date: '2030-12-31',
        email: `${role.toLowerCase()}@zentry.com`,
        supervisor_id: role === 'Sales' ? 'leader-1-id' : null
      },
      {
        id: 'sales-1',
        full_name: 'Budi Santoso',
        role: 'Sales',
        subscription_status: 'Active',
        subscription_end_date: '2030-12-31',
        email: 'sales1@zentry.com',
        supervisor_id: 'dummy-admin-id'
      },
      {
        id: 'sales-2',
        full_name: 'Siti Aminah',
        role: 'Sales',
        subscription_status: 'Active',
        subscription_end_date: '2030-12-31',
        email: 'sales2@zentry.com',
        supervisor_id: 'dummy-admin-id'
      },
      {
        id: 'leader-1-id',
        full_name: 'Andi Pratama',
        role: 'Leader',
        subscription_status: 'Active',
        subscription_end_date: '2030-12-31',
        email: 'leader1@zentry.com',
        supervisor_id: 'dummy-admin-id'
      }
    ],
    submissions: [
      {
        id: '1',
        status_pemasangan: 'terlaksana',
        biaya_total: 350000,
        created_at: new Date().toISOString(),
        paket_layanan: 'Fiber',
        paket_spec: '100 Mbps',
        promo: 'Pay 5 Get 6',
        sales_id: 'sales-1',
        is_draft: false,
        nama_lengkap: 'Budi Santoso',
        homepass_id: 'HP-001',
        koordinat: '-6.200000, 106.816666',
        sales: { full_name: 'Budi Santoso' }
      },
      {
        id: '2',
        status_pemasangan: 'pending',
        biaya_total: 250000,
        created_at: new Date(Date.now() - 86400000).toISOString(),
        paket_layanan: 'Safe',
        paket_spec: '50 Mbps',
        promo: 'Normal',
        sales_id: 'sales-2',
        is_draft: false,
        nama_lengkap: 'Siti Aminah',
        homepass_id: 'HP-002',
        koordinat: '-6.210000, 106.826666',
        sales: { full_name: 'Siti Aminah' }
      }
    ],
    signatures: [
      {
        id: '1',
        user_id: 'dummy-admin-id',
        signature_url: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII='
      }
    ]
  };

  const createBuilder = (table: string) => {
    let currentData = dummyDataMap[table] || [];

    const builder: any = {
      select: () => builder,
      insert: () => builder,
      update: () => builder,
      delete: () => builder,
      eq: (field?: string, val?: any) => {
        if (field && val !== undefined && Array.isArray(currentData)) {
          const filtered = currentData.filter((item: any) => item[field] === val);
          if (filtered.length > 0) {
            currentData = filtered;
          }
        }
        return builder;
      },
      neq: () => builder,
      gt: () => builder,
      gte: () => builder,
      lt: () => builder,
      lte: () => builder,
      like: () => builder,
      ilike: () => builder,
      is: () => builder,
      in: () => builder,
      order: () => builder,
      limit: () => builder,
      range: () => builder,
      single: async () => ({
        data: Array.isArray(currentData) ? currentData[0] || null : currentData,
        error: null
      }),
      maybeSingle: async () => ({
        data: Array.isArray(currentData) ? currentData[0] || null : currentData,
        error: null
      }),
      then: (resolve: any, reject: any) => {
        resolve({ data: currentData, error: null });
      }
    };

    return builder;
  };

  return {
    auth: {
      getUser: async () => ({ data: { user: dummyUser }, error: null }),
      getSession: async () => ({ data: { session: { user: dummyUser } }, error: null }),
      signInWithPassword: async () => ({ data: { user: dummyUser, session: { user: dummyUser } }, error: null }),
      signOut: async () => {
        if (typeof document !== 'undefined') {
          document.cookie = "dummy_auth=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
          document.cookie = "dummy_role=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
        }
        return { error: null };
      },
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
    },
    from: (table: string) => createBuilder(table),
    storage: {
      from: () => ({
        upload: async () => ({ data: { path: 'dummy.pdf' }, error: null }),
        getPublicUrl: () => ({ data: { publicUrl: 'https://placeholder.supabase.co/dummy.pdf' } })
      })
    }
  };
}
