import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import LeaderDashboardClient from "@/components/LeaderDashboardClient";
import ExportExcelButton from "@/components/ExportExcelButton";

export const dynamic = 'force-dynamic';

export default async function LeaderDashboard() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  // 1. Dapatkan profile leader
  const { data: profile } = await supabase
    .from("users")
    .select("full_name, role")
    .eq("id", user.id)
    .single();

  if (profile?.role !== 'Leader') {
    // Keamanan ekstra jika bukan leader
    redirect("/");
  }

  // 2. Dapatkan data pendaftaran dari tim (RLS akan otomatis memfilter milik timnya saja)
  // Kita perlu melakukan join dengan public.users untuk mendapatkan nama sales
  const { data: submissions, error: subError } = await supabase
    .from("submissions")
    .select(`
      id, 
      status_pemasangan, 
      biaya_total, 
      paket_layanan, 
      created_at,
      sales_id,
      sales:users(full_name)
    `)
    .eq('is_draft', false);

  if (subError) {
    console.error("Error fetching team submissions:", subError);
  }

  // 3. Dapatkan daftar anggota tim (Sales)
  const { data: teamMembers } = await supabase
    .from("users")
    .select("id, full_name, role, supervisor_id")
    .eq("supervisor_id", user.id);

  const validTeamMembers = Array.isArray(teamMembers) ? teamMembers : [];

  // Tambahkan diri sendiri (Leader) ke dalam usersList agar modal memiliki context Leader
  const usersList = [
    { id: user.id, full_name: profile.full_name, role: 'Leader', supervisor_id: null },
    ...validTeamMembers
  ];

  // Kalkulasi statistik
  const validSubmissions = Array.isArray(submissions) ? submissions : [];

  return (
    <div className="animate-fade-in" style={{ padding: 'var(--spacing-xl)' }}>
      <header style={{ marginBottom: 'var(--spacing-xl)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 className="h2" style={{ color: 'var(--text-primary)' }}>Dashboard Tim, {profile?.full_name}</h1>
          <p className="text-body">Ringkasan performa kolektif seluruh anggota tim Anda.</p>
        </div>
        <ExportExcelButton role="Leader" currentUserId={user.id} usersList={usersList} />
      </header>

      <LeaderDashboardClient submissions={validSubmissions} teamMembers={validTeamMembers} />
    </div>
  );
}
