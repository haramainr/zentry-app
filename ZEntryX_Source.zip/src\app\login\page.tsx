"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  LogIn, 
  Zap, 
  ShieldCheck, 
  BarChart3, 
  Cloud 
} from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (formData.password === 'admin123' && (
        formData.email === 'admin' || formData.email.startsWith('admin') ||
        formData.email.startsWith('sales') || formData.email.startsWith('leader') ||
        formData.email.startsWith('manager') || formData.email.startsWith('dev')
      )) {
        let role = 'Manager';
        let target = '/manager';
        if (formData.email.startsWith('sales')) { role = 'Sales'; target = '/sales'; }
        else if (formData.email.startsWith('leader')) { role = 'Leader'; target = '/leader'; }
        else if (formData.email.startsWith('dev')) { role = 'Developer'; target = '/developer'; }
        
        document.cookie = `dummy_auth=true; path=/; max-age=86400`;
        document.cookie = `dummy_role=${role}; path=/; max-age=86400`;
        window.location.href = target;
        return;
      }

      const { error: authError } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });

      if (authError) throw authError;

      window.location.href = '/'; 
      
    } catch (err: any) {
      setError(err.message || "Email atau password salah");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`
        }
      });
      if (error) throw error;
    } catch (err: any) {
      setError(err.message || "Gagal login dengan Google");
    }
  };

  return (
    <div className="login-page-container">
      
      {/* Dark Royal Blue Overlay over Realistic Corporate Office Background */}
      <div className="bg-overlay" />
      <div className="bg-pattern-dots" />
      <div className="glow-sphere sphere-top-right" />
      <div className="glow-sphere sphere-bottom-left" />

      <main className="login-main">
        <div className="split-layout">
          
          {/* ================= HERO SECTION (LEFT - 55-60%) ================= */}
          <div className="hero-section">
            {/* Kosong: seluruh teks dan ilustrasi sudah digenerate langsung dalam satu gambar background */}
          </div>

          {/* ================= LOGIN CARD (RIGHT - 40-45%) ================= */}
          <div className="login-card-wrapper">
            <div className="login-card glassmorphism-card">
              
              {/* Logo & Judul Card */}
              <div className="card-header">
                <div className="card-logo-box">
                  <Image 
                    src="/zentry-logo.png" 
                    width={260} 
                    height={70} 
                    alt="ZEntry Logo" 
                    style={{ objectFit: 'contain' }} 
                  />
                </div>
                <h2 className="card-brand-name">ZentryX</h2>
              </div>

              <h3 className="card-title">Portal Internal</h3>
              <p className="card-subtitle">ZEntry Database System</p>

              {/* Error Banner */}
              {error && (
                <div className="error-banner">
                  <span className="error-dot" />
                  <span>{error}</span>
                </div>
              )}

              {/* Form Login */}
              <form onSubmit={handleLogin} className="login-form">
                
                {/* Kolom Email */}
                <div className="form-group">
                  <label className="form-label">Email</label>
                  <div className="input-container">
                    <Mail size={20} className="input-icon" />
                    <input 
                      type="text" 
                      name="email" 
                      required 
                      value={formData.email} 
                      onChange={handleChange} 
                      placeholder="Masukkan email atau username" 
                      className="form-input" 
                    />
                  </div>
                </div>

                {/* Kolom Password */}
                <div className="form-group">
                  <label className="form-label">Password</label>
                  <div className="input-container">
                    <Lock size={20} className="input-icon" />
                    <input 
                      type={showPassword ? "text" : "password"} 
                      name="password" 
                      required 
                      value={formData.password} 
                      onChange={handleChange} 
                      placeholder="Masukkan password" 
                      className="form-input password-input" 
                    />
                    <button 
                      type="button" 
                      onClick={() => setShowPassword(!showPassword)} 
                      className="toggle-pwd-btn"
                      title={showPassword ? "Sembunyikan password" : "Tampilkan password"}
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                </div>

                {/* Ingat Saya & Lupa Password */}
                <div className="form-options-row">
                  <label className="remember-me">
                    <input type="checkbox" className="custom-checkbox" />
                    <span>Ingat saya</span>
                  </label>
                  <Link href="/forgot-password" className="forgot-link">
                    Lupa Password?
                  </Link>
                </div>

                {/* Tombol Masuk */}
                <button type="submit" disabled={loading} className="submit-btn">
                  {loading ? (
                    <span className="btn-content">
                      <span className="spinner" /> <span>Memproses...</span>
                    </span>
                  ) : (
                    <span className="btn-content">
                      <LogIn size={20} className="btn-icon" /> <span>Masuk</span>
                    </span>
                  )}
                </button>

                {/* Divider */}
                <div className="divider">
                  <span className="divider-line" />
                  <span className="divider-text">atau</span>
                  <span className="divider-line" />
                </div>

                {/* Tombol Google */}
                <button 
                  type="button" 
                  onClick={handleGoogleLogin} 
                  disabled={loading} 
                  className="google-btn"
                >
                  <svg viewBox="0 0 24 24" width="20" height="20">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                  <span>Masuk dengan Google</span>
                </button>

              </form>

              {/* Footer Card */}
              <div className="card-footer">
                <p className="footer-register-text">
                  Belum punya akun? <Link href="/register" className="register-link">Buat Akun Baru</Link>
                </p>
                <div className="copyright-box">
                  <p>© 2026 ZEntryX. All rights reserved.</p>
                  <p>Developed by <span className="dev-name">Icun</span>, <span className="dev-name">Haramain</span>, <span className="dev-name">Fawwaz</span>, and <span className="dev-name">Rafi</span> at Zyntaxera</p>
                </div>
              </div>

            </div>
          </div>

        </div>
      </main>

      {/* ================= SCOPED CSS STYLES (ENTERPRISE GLASSMORPHISM) ================= */}
      <style jsx>{`
        .login-page-container {
          min-height: 100vh;
          min-height: 100dvh;
          display: flex;
          flex-direction: column;
          background-color: #F4F8FF;
          background-image: url('/bg-login-new.png?v=4k_fluent_design');
          background-size: cover;
          background-position: center left;
          background-repeat: no-repeat;
          image-rendering: -webkit-optimize-contrast;
          image-rendering: high-quality;
          -webkit-backface-visibility: hidden;
          backface-visibility: hidden;
          transform: translateZ(0);
          position: relative;
          overflow-x: hidden;
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          box-sizing: border-box;
        }

        @media (min-width: 1024px) {
          .login-page-container {
            height: 100vh;
            max-height: 100vh;
            overflow: hidden;
          }
        }

        .bg-overlay,
        .bg-pattern-dots,
        .glow-sphere {
          display: none;
        }

        .login-main {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px 16px;
          position: relative;
          z-index: 10;
        }

        @media (min-width: 768px) {
          .login-main {
            padding: 28px 24px;
          }
        }

        @media (min-width: 1024px) {
          .login-main {
            padding: 16px 36px;
            height: 100vh;
            max-height: 100vh;
            overflow: hidden;
          }
        }

        .split-layout {
          max-width: 1320px;
          width: 100%;
          display: flex;
          flex-direction: column;
          gap: 36px;
          align-items: center;
          margin: auto 0;
        }

        @media (min-width: 1024px) {
          .split-layout {
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            gap: 48px;
            max-height: calc(100vh - 32px);
          }
          .hero-section {
            flex: 1.3;
            max-width: 660px;
          }
          .login-card-wrapper {
            flex: 1;
            max-width: 440px;
          }
        }

        @media (min-width: 1280px) {
          .split-layout {
            gap: 60px;
          }
        }

        /* Hero Section */
        .hero-section {
          display: flex;
          flex-direction: column;
          width: 100%;
          color: #FFFFFF;
        }

        .hero-brand {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 18px;
        }

        @media (min-width: 768px) {
          .hero-brand {
            margin-bottom: 22px;
          }
        }

        .logo-badge {
          padding: 8px 16px;
          height: 52px;
          width: auto;
          min-width: 170px;
          border-radius: 14px;
          background: #FFFFFF;
          border: 1px solid rgba(255, 255, 255, 0.4);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }

        .logo-badge :global(img) {
          width: auto !important;
          height: 36px !important;
          max-width: 100% !important;
          object-fit: contain;
        }

        .hero-brand-text {
          display: none;
        }

        .brand-title {
          font-size: 24px;
          font-weight: 900;
          color: #FFFFFF;
          line-height: 1;
          margin: 0;
          letter-spacing: -0.02em;
        }

        @media (min-width: 768px) {
          .brand-title {
            font-size: 28px;
          }
        }

        .brand-sub {
          font-size: 8.5px;
          font-weight: 800;
          color: #60A5FA;
          letter-spacing: 2px;
          margin-top: 4px;
        }

        @media (min-width: 768px) {
          .brand-sub {
            font-size: 9.5px;
            letter-spacing: 2.2px;
          }
        }

        .hero-headline {
          font-size: 34px;
          font-weight: 900;
          color: #FFFFFF;
          line-height: 1.15;
          letter-spacing: -0.03em;
          margin: 0 0 12px 0;
          text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        @media (min-width: 768px) {
          .hero-headline {
            font-size: 42px;
            margin-bottom: 14px;
          }
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .hero-headline {
            font-size: 50px;
          }
        }

        .highlight-blue {
          color: #3B82F6;
          background: linear-gradient(90deg, #60A5FA 0%, #3B82F6 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          filter: drop-shadow(0 0 20px rgba(59, 130, 246, 0.4));
        }

        .hero-subheadline {
          font-size: 14px;
          color: #E2E8F0;
          line-height: 1.6;
          max-width: 500px;
          margin: 0 0 22px 0;
          text-shadow: 0 1px 4px rgba(0, 0, 0, 0.4);
        }

        @media (min-width: 768px) {
          .hero-subheadline {
            font-size: 15.5px;
            margin-bottom: 28px;
          }
        }

        .feature-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 10px;
        }

        @media (min-width: 640px) {
          .feature-grid {
            grid-template-columns: 1fr 1fr;
            gap: 12px;
          }
        }

        .feature-item {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 12px 14px;
          border-radius: 16px;
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(255, 255, 255, 0.12);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .feature-item:hover {
          background: rgba(255, 255, 255, 0.12);
          border-color: rgba(96, 165, 250, 0.4);
          transform: translateY(-3px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3), 0 0 20px rgba(59, 130, 246, 0.2);
        }

        .feature-icon {
          width: 38px;
          height: 38px;
          border-radius: 10px;
          background: linear-gradient(135deg, rgba(37, 99, 235, 0.5) 0%, rgba(59, 130, 246, 0.2) 100%);
          border: 1px solid rgba(96, 165, 250, 0.4);
          color: #60A5FA;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
          transition: transform 0.3s ease;
        }

        .feature-item:hover .feature-icon {
          transform: scale(1.1) rotate(5deg);
        }

        .float-delay-1 { animation: float-icon 4s ease-in-out infinite; }
        .float-delay-2 { animation: float-icon 4s ease-in-out 1s infinite; }
        .float-delay-3 { animation: float-icon 4s ease-in-out 2s infinite; }
        .float-delay-4 { animation: float-icon 4s ease-in-out 3s infinite; }

        @keyframes float-icon {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }

        .feature-title {
          font-size: 14px;
          font-weight: 700;
          color: #FFFFFF;
          margin: 0 0 2px 0;
        }

        @media (min-width: 768px) {
          .feature-title {
            font-size: 15px;
          }
        }

        .feature-desc {
          font-size: 12px;
          color: #CBD5E1;
          line-height: 1.4;
          margin: 0;
        }

        /* Glassmorphism Premium Login Card */
        .login-card-wrapper {
          width: 100%;
        }

        .glassmorphism-card {
          background: rgba(255, 255, 255, 0.88);
          border: 1px solid rgba(255, 255, 255, 0.75);
          border-radius: 28px;
          padding: 24px 20px;
          backdrop-filter: blur(28px);
          -webkit-backdrop-filter: blur(28px);
          box-shadow: 
            0 25px 70px -15px rgba(0, 0, 0, 0.45), 
            0 0 25px rgba(37, 99, 235, 0.15),
            inset 0 0 2px 1px rgba(255, 255, 255, 0.9);
          animation: float-card 6s ease-in-out infinite;
          transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @media (min-width: 640px) {
          .glassmorphism-card {
            padding: 28px 28px;
            border-radius: 30px;
          }
        }

        @media (min-width: 1024px) {
          .glassmorphism-card {
            padding: 24px 32px;
            border-radius: 32px;
          }
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .glassmorphism-card {
            padding: 34px 36px;
          }
        }

        .glassmorphism-card:hover {
          background: rgba(255, 255, 255, 0.92);
          box-shadow: 
            0 30px 80px -15px rgba(0, 0, 0, 0.55), 
            0 0 35px rgba(37, 99, 235, 0.25),
            inset 0 0 2px 1px #FFFFFF;
          transform: translateY(-3px);
        }

        @keyframes float-card {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }

        .card-header {
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-bottom: 12px;
        }

        .card-logo-box {
          width: auto;
          max-width: 280px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 12px;
          transition: transform 0.3s ease;
        }

        .card-logo-box :global(img) {
          width: auto !important;
          height: 60px !important;
          max-width: 100% !important;
          object-fit: contain;
        }

        .glassmorphism-card:hover .card-logo-box {
          transform: scale(1.05);
        }

        .card-brand-name {
          display: none;
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .card-brand-name {
            font-size: 25px;
          }
        }

        .card-title {
          font-size: 18px;
          font-weight: 800;
          color: #2563EB;
          text-align: center;
          margin: 0 0 2px 0;
        }

        @media (min-width: 768px) {
          .card-title {
            font-size: 20px;
          }
        }

        .card-subtitle {
          font-size: 13px;
          font-weight: 600;
          color: #64748B;
          text-align: center;
          margin: 0 0 18px 0;
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .card-subtitle {
            font-size: 14px;
            margin-bottom: 24px;
          }
        }

        /* Error Banner */
        .error-banner {
          background: rgba(254, 242, 242, 0.95);
          border: 1px solid #FECACA;
          color: #DC2626;
          padding: 10px 14px;
          border-radius: 12px;
          font-size: 13px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 14px;
          box-shadow: 0 4px 12px rgba(220, 38, 38, 0.08);
        }

        .error-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #DC2626;
          flex-shrink: 0;
        }

        /* Form */
        .login-form {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .login-form {
            gap: 16px;
          }
        }

        .form-group {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .form-label {
          font-size: 13px;
          font-weight: 700;
          color: #1E293B;
        }

        .input-container {
          display: flex;
          align-items: center;
          width: 100%;
          height: 46px;
          background: rgba(255, 255, 255, 0.9);
          border: 1.5px solid rgba(203, 213, 225, 0.8);
          border-radius: 12px;
          padding: 0 14px;
          gap: 12px;
          transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
          box-sizing: border-box;
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .input-container {
            height: 52px;
            border-radius: 14px;
          }
        }

        .input-container:hover {
          background: #FFFFFF;
          border-color: #94A3B8;
        }

        .input-container:focus-within {
          background: #FFFFFF;
          border-color: #2563EB;
          box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15);
        }

        .input-icon {
          color: #64748B;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: color 0.2s ease;
        }

        .input-container:focus-within .input-icon {
          color: #2563EB;
        }

        .form-input {
          flex: 1;
          height: 100%;
          background: transparent !important;
          border: none !important;
          padding: 0 !important;
          margin: 0;
          font-size: 14px;
          color: #0F172A;
          outline: none !important;
          box-shadow: none !important;
          width: 100%;
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .form-input {
            font-size: 15px;
          }
        }

        .form-input::placeholder {
          color: #94A3B8;
          font-weight: 400;
        }

        .toggle-pwd-btn {
          color: #64748B;
          background: transparent;
          border: none;
          cursor: pointer;
          padding: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          flex-shrink: 0;
          transition: all 0.2s ease;
        }

        .toggle-pwd-btn:hover {
          color: #2563EB;
          background: rgba(37, 99, 235, 0.08);
        }

        /* Remember Me & Forgot Password Row */
        .form-options-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: -2px;
        }

        .remember-me {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12.5px;
          font-weight: 500;
          color: #475569;
          cursor: pointer;
          user-select: none;
        }

        .custom-checkbox {
          width: 15px;
          height: 15px;
          border-radius: 4px;
          border: 1.5px solid #CBD5E1;
          accent-color: #2563EB;
          cursor: pointer;
        }

        .forgot-link {
          font-size: 12.5px;
          font-weight: 600;
          color: #2563EB;
          text-decoration: none;
          transition: color 0.2s ease;
        }

        .forgot-link:hover {
          color: #1D4ED8;
          text-decoration: underline;
        }

        /* Submit Button */
        .submit-btn {
          width: 100%;
          height: 46px;
          margin-top: 2px;
          background: linear-gradient(90deg, #2563EB 0%, #3B82F6 100%);
          color: #FFFFFF;
          border: none;
          border-radius: 12px;
          font-size: 15px;
          font-weight: 700;
          cursor: pointer;
          box-shadow: 0 8px 20px -4px rgba(37, 99, 235, 0.45);
          transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .submit-btn, .google-btn {
            height: 52px;
            border-radius: 14px;
            font-size: 16px;
          }
        }

        .submit-btn:hover:not(:disabled) {
          box-shadow: 0 14px 28px -4px rgba(37, 99, 235, 0.65);
          transform: translateY(-2px);
          background: linear-gradient(90deg, #1D4ED8 0%, #2563EB 100%);
        }

        .submit-btn:active:not(:disabled) {
          transform: translateY(0);
          box-shadow: 0 6px 16px -4px rgba(37, 99, 235, 0.45);
        }

        .submit-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .btn-content {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
        }

        .btn-icon {
          transition: transform 0.25s ease;
        }

        .submit-btn:hover:not(:disabled) .btn-icon {
          transform: translateX(3px);
        }

        .spinner {
          width: 18px;
          height: 18px;
          border: 2.5px solid rgba(255, 255, 255, 0.3);
          border-top-color: #FFFFFF;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        /* Divider */
        .divider {
          display: flex;
          align-items: center;
          gap: 12px;
          margin: 6px 0;
        }

        .divider-line {
          flex: 1;
          height: 1px;
          background: rgba(203, 213, 225, 0.8);
        }

        .divider-text {
          font-size: 12.5px;
          font-weight: 500;
          color: #64748B;
        }

        /* Google Button */
        .google-btn {
          width: 100%;
          height: 46px;
          background: rgba(255, 255, 255, 0.95);
          border: 1.5px solid #E2E8F0;
          border-radius: 12px;
          font-size: 14px;
          font-weight: 700;
          color: #1E293B;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .google-btn:hover:not(:disabled) {
          background: #F8FAFC;
          border-color: #CBD5E1;
          box-shadow: 0 6px 18px rgba(0, 0, 0, 0.06);
          transform: translateY(-1.5px);
        }

        .google-btn:active:not(:disabled) {
          transform: translateY(0);
        }

        /* Footer Card */
        .card-footer {
          margin-top: 16px;
          padding-top: 12px;
          border-top: 1px solid rgba(226, 232, 240, 0.8);
          text-align: center;
        }

        @media (min-width: 1400px) and (min-height: 880px) {
          .card-footer {
            margin-top: 22px;
            padding-top: 16px;
          }
        }

        .footer-register-text {
          font-size: 13px;
          color: #64748B;
          margin: 0 0 10px 0;
        }

        .register-link {
          font-weight: 700;
          color: #2563EB;
          text-decoration: none;
          transition: color 0.2s ease;
        }

        .register-link:hover {
          color: #1D4ED8;
          text-decoration: underline;
        }

        .copyright-box {
          font-size: 10.5px;
          color: #94A3B8;
          line-height: 1.45;
        }

        .copyright-box p {
          margin: 1px 0;
        }

        .dev-name {
          color: #3B82F6;
          font-weight: 600;
        }
      `}</style>
    </div>
  );
}
