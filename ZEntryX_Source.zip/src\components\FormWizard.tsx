"use client";

import React, { useState, useRef, useEffect } from "react";
import { CheckCircle, ChevronRight, ChevronLeft, Save, Calendar, Upload, Plus, Minus } from "lucide-react";
import SignatureCanvas from 'react-signature-canvas';
import Select from 'react-select';
import { AREAS, PACKAGE_CATEGORIES, PAYMENT_TERMS, PACKAGES_DATA, VAS_DATA, SMARTBOX_PRICES } from '@/lib/packagesData';

export default function FormWizard({ initialData, caeName, tlName }: { initialData?: any, caeName?: string, tlName?: string }) {
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 6;
  
  const sigCanvas = useRef<SignatureCanvas>(null);
  const ccSigCanvas = useRef<SignatureCanvas>(null);
  
  let parsedVas: string[] = [];
  let parsedExtras: any = {};
  if (initialData?.vas) {
    try {
      const decoded = JSON.parse(initialData.vas);
      if (Array.isArray(decoded)) {
        if (decoded.length === 1 && typeof decoded[0] === 'string' && decoded[0].startsWith('[')) {
          parsedVas = JSON.parse(decoded[0]);
        } else {
          parsedVas = decoded;
        }
      } else if (typeof decoded === 'object' && decoded !== null) {
        parsedVas = decoded.vas || [];
        parsedExtras = decoded;
      } else {
        parsedVas = initialData.vas.split(', ').filter(Boolean);
      }
    } catch (e) {
      parsedVas = initialData.vas.split(', ').filter(Boolean);
    }
  }

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Simpan data Tanda Tangan ke state agar tidak hilang saat unmount
  const [signatureData, setSignatureData] = useState<string | null>(initialData?.signature_base64 || null);
  const [ccSignatureData, setCcSignatureData] = useState<string | null>(initialData?.cc_signature_base64 || null);
  
  // State untuk ID draft agar auto-save tidak membuat draft baru berkali-kali
  const [draftId, setDraftId] = useState(initialData?.id || null);

  useEffect(() => {
    // Sinkronisasi step dari URL saat mount dan saat popstate
    const handlePopState = () => {
      const url = new URL(window.location.href);
      const step = parseInt(url.searchParams.get('step') || '1', 10);
      if (step >= 1 && step <= totalSteps) {
        setCurrentStep(step);
      }
    };
    window.addEventListener('popstate', handlePopState);
    
    // Inisialisasi awal
    const url = new URL(window.location.href);
    const initialUrlStep = parseInt(url.searchParams.get('step') || '1', 10);
    if (initialUrlStep >= 1 && initialUrlStep <= totalSteps && initialUrlStep !== currentStep) {
      setCurrentStep(initialUrlStep);
    } else if (!url.searchParams.get('step')) {
      url.searchParams.set('step', '1');
      window.history.replaceState({}, '', url);
    }
    
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    // Restore signatures to canvas if they exist
    if (initialData?.signature_base64 && sigCanvas.current && sigCanvas.current.isEmpty()) {
      sigCanvas.current.fromDataURL(initialData.signature_base64);
    }
    if (initialData?.cc_signature_base64 && ccSigCanvas.current && ccSigCanvas.current.isEmpty()) {
      ccSigCanvas.current.fromDataURL(initialData.cc_signature_base64);
    }
  }, [initialData]);

  // Restore dari state saat step berpindah (mencegah ttd hilang)
  useEffect(() => {
    if (currentStep === 6 && signatureData && sigCanvas.current && sigCanvas.current.isEmpty()) {
      sigCanvas.current.fromDataURL(signatureData);
    }
    if (currentStep === 5 && ccSignatureData && ccSigCanvas.current && ccSigCanvas.current.isEmpty()) {
      ccSigCanvas.current.fromDataURL(ccSignatureData);
    }
  }, [currentStep, signatureData, ccSignatureData]);

  const [isDrafting, setIsDrafting] = useState(false);
  const [isOcring, setIsOcring] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleOcrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsOcring(true);
      try {
        const { parseKtpOcr } = await import("@/lib/ocr");
        const ocrData = await parseKtpOcr(e.target.files[0]);
        if (ocrData) {
          setFormData(prev => ({
            ...prev,
            ktp: ocrData.nik || prev.ktp,
            namaLengkap: ocrData.nama || prev.namaLengkap,
            tempatLahir: ocrData.tempatLahir || prev.tempatLahir,
            tanggalLahir: ocrData.tglLahir || prev.tanggalLahir,
            jenisKelamin: ocrData.jenisKelamin || prev.jenisKelamin,
          }));
          alert("Beberapa data berhasil diisi dari KTP. Silakan periksa kembali ketepatannya.");
        } else {
          alert("Gagal membaca KTP. Silakan isi manual.");
        }
      } catch (err) {
        alert("Error memindai KTP.");
      } finally {
        setIsOcring(false);
        // Reset file input so user can select the same file again if needed
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    }
  };

  const [formData, setFormData] = useState({
    namaLengkap: initialData?.nama_lengkap || '',
    tempatLahir: initialData?.tempat_lahir || '',
    tanggalLahir: initialData?.tanggal_lahir || '',
    ktp: initialData?.ktp || '',
    jenisKelamin: initialData?.jenis_kelamin || '',
    telpSelular: initialData?.telp_selular || '',
    telpRumah: initialData?.telp_rumah || '',
    alamat: initialData?.alamat || '',
    rt: initialData?.rt || '',
    rw: initialData?.rw || '',
    kodePos: initialData?.kode_pos || '',
    statusKepemilikan: initialData?.status_kepemilikan || '',
    email: initialData?.email || '',
    area: 'Regular FS',
    promoTerm: 'Bulanan (Regular)',
    paketLayanan: initialData?.paket_layanan || 'Fiber',
    paketSpec: initialData?.paket_spec || '',
    vas: parsedVas,
    promo: initialData?.promo || '',
    routerQty: initialData?.router_qty ? initialData.router_qty.toString() : (parsedExtras.routerQty || ''),
    routerText: parsedExtras.routerText || '',
    routerPrice: parsedExtras.routerPrice || '',
    smartboxQty: initialData?.smartbox_qty ? initialData.smartbox_qty.toString() : (parsedExtras.smartboxQty || ''),
    smartboxText: parsedExtras.smartboxText || '',
    customQty: parsedExtras.customQty || '',
    customText: parsedExtras.customText || '',
    customPrice: parsedExtras.customPrice || '',
    densTvCheck: parsedExtras.densTvCheck || false,
    visionTvCheck: parsedExtras.visionTvCheck || false,
    addon1Check: parsedExtras.addon1Check || false,
    addon1Text: parsedExtras.addon1Text || '',
    addon2Check: false,
    addon2Text: '',
    username: initialData?.username_zentry || '',
    tglPemasangan: initialData?.tgl_pemasangan || '',
    waktuPemasangan: initialData?.waktu_pemasangan || '',
    catatan: initialData?.catatan || '',
    homepassId: initialData?.homepass_id || '',
    titikKoordinat: initialData?.titik_koordinat || '',
    
    ccNama: initialData?.cc_nama || '',
    ccNomor: initialData?.cc_nomor || '',
    ccBerlaku: initialData?.cc_berlaku || '',
    ccBank: initialData?.cc_bank || '',
    ccWewenang: initialData?.cc_wewenang || false,
    
    biayaPemasangan: initialData?.biaya_pemasangan ? initialData.biaya_pemasangan.toString() : '0',
    biayaPemasanganDropdown: initialData?.biaya_pemasangan ? initialData.biaya_pemasangan.toString() : '0',
    biayaPaket: initialData?.biaya_paket ? initialData.biaya_paket.toString() : '0',
    biayaTambahan: initialData?.biaya_tambahan ? initialData.biaya_tambahan.toString() : '0',
    biayaServices: initialData?.biaya_services ? initialData.biaya_services.toString() : '0',
    biayaAddons: initialData?.biaya_addons ? initialData.biaya_addons.toString() : '0',
    biayaPerangkat: initialData?.biaya_perangkat ? initialData.biaya_perangkat.toString() : '0',
    biayaLainnya: initialData?.biaya_lainnya ? initialData.biaya_lainnya.toString() : '5000',
    caeName: caeName || '',
    tlName: tlName || '',
  });

  const [kalkulasi, setKalkulasi] = useState({
    ppn: 0,
    total: 0
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const target = e.target as HTMLInputElement;
    const { name, value, type, checked } = target;
    
    setFormData(prev => {
      let newData = { ...prev, [name]: type === 'checkbox' ? checked : value };
      
      // Auto-check custom add-on TV if text is typed
      if (name === 'addon1Text' && value.trim() !== '') {
        newData.addon1Check = true;
      }
      
      // Auto-fill biaya jika dropdown berubah
      if (name === 'area') {
        const newAreaData = PACKAGES_DATA[newData.area] || {};
        const categoryMap: Record<string, string> = { 'Fiber': 'Fiber Reguler', 'Safe': 'Fiber Safe', 'Soho': 'Fiber Soho' };
        
        let newPaketLayanan = newData.paketLayanan;
        if (!newAreaData[categoryMap[newPaketLayanan]]) {
          const availableCats = Object.keys(newAreaData);
          if (availableCats.length > 0) {
            const reverseMap: Record<string, string> = { 'Fiber Reguler': 'Fiber', 'Fiber Safe': 'Safe', 'Fiber Soho': 'Soho' };
            newPaketLayanan = reverseMap[availableCats[0]] || 'Fiber';
          }
        }
        newData.paketLayanan = newPaketLayanan;
        
        const terms = (newAreaData[categoryMap[newPaketLayanan]]?.terms) || [];
        newData.promoTerm = terms.length > 0 ? terms[0] : 'Bulanan (Regular)';
        
        newData.paketSpec = '';
        newData.biayaPaket = '0';
      } else if (name === 'paketLayanan') {
        const areaData = PACKAGES_DATA[newData.area] || {};
        const categoryMap: Record<string, string> = { 'Fiber': 'Fiber Reguler', 'Safe': 'Fiber Safe', 'Soho': 'Fiber Soho' };
        const categoryName = categoryMap[newData.paketLayanan];
        const newTerms = (areaData[categoryName]?.terms) || [];
        
        if (!newTerms.includes(newData.promoTerm) && newTerms.length > 0) {
          newData.promoTerm = newTerms[0];
        }
        
        newData.paketSpec = '';
        newData.biayaPaket = '0';
      }
      
      if (['area', 'paketLayanan', 'promoTerm', 'paketSpec'].includes(name)) {
        const areaData = PACKAGES_DATA[newData.area];
        const categoryMap: Record<string, string> = { 'Fiber': 'Fiber Reguler', 'Safe': 'Fiber Safe', 'Soho': 'Fiber Soho' };
        const category = categoryMap[newData.paketLayanan];
        
        if (areaData && areaData[category] && newData.paketSpec) {
          if (newData.promoTerm === 'Bulanan (Regular)' && areaData[category].monthlyPrices?.[newData.paketSpec]) {
            newData.biayaPaket = areaData[category].monthlyPrices[newData.paketSpec].basicPrice.toString();
            newData.biayaPemasangan = areaData[category].monthlyPrices[newData.paketSpec].setupFee.toString();
          } else {
            const prices = areaData[category].prices?.[newData.promoTerm];
            if (prices && prices[newData.paketSpec] !== undefined) {
              newData.biayaPaket = prices[newData.paketSpec].toString();
            } else {
              newData.biayaPaket = '0';
            }
            if (newData.promoTerm && newData.promoTerm.includes('Advance Pay')) {
              newData.biayaPemasangan = '0';
            }
          }
        } else if (name === 'paketSpec' && !newData.paketSpec) {
          newData.biayaPaket = '0';
        }

        // Auto-fill Catatan (Notes)
        const getAutoNotes = (area: string, cat: string, term: string) => {
          if (area === 'Regular FS') {
            if (term === 'Advance Pay 5 Get 6') return "Regular Promo July 2026 - Bill in Advance Pay 5 Get 6 - NAB";
            if (term === 'Advance Pay 9 Get 12') return "Regular Promo July 2026 - Bill in Advance Pay 9 Get 12 - NAB";
            return "Regular Promo July 2026 - NAB";
          }
          if (area === 'Pro') {
            if (term === 'Advance Pay 6 Get 7') return "Regular Promo Juli 2025 - SOHO PRO - Bill in Advance Pay 6 Get 7";
            if (term === 'Advance Pay 12 Get 15') return "Regular Promo Juli 2025 - SOHO PRO - Bill in Advance Pay 12 Get 15";
            return "Regular Promo Juli 2025 - SOHO PRO";
          }
          if (area === 'PIK 1 JMS') {
            if (cat === 'Fiber Soho') {
              if (term === 'Advance Pay 6 Get 7') return "Fiber SOHO Promo - PIK 1 Area - Bill in Advance Pay 6 Get 7 June 2024";
              if (term === 'Advance Pay 12 Get 14') return "Fiber SOHO Promo - PIK 1 Area - Bill in Advance Pay 12 Get 14 June 2024";
              return "Fiber SOHO Promo - PIK 1 Area June 2024";
            }
            if (term === 'Advance Pay 6 Get 7') return "Regular Promo June 2024 - PIK 1 JMS Area - Bill in Advance Pay 6 Get 7";
            if (term === 'Advance Pay 12 Get 14') return "Regular Promo June 2024 - PIK 1 JMS Area - Bill in Advance Pay 12 Get 14";
            return "Regular Promo June 2024 - PIK 1 JMS Area";
          }
          if (area === 'PIK 2 JMS') {
            if (cat === 'Fiber Soho') {
              if (term === 'Advance Pay 6 Get 7') return "Fiber SOHO Promo - PIK 2 Area - Bill in Advance Pay 6 Get 7 June 2024";
              if (term === 'Advance Pay 12 Get 14') return "Fiber SOHO Promo - PIK 2 Area - Bill in Advance Pay 12 Get 14 June 2024";
              return "Fiber SOHO Promo - PIK 2 Area May 2024";
            }
            if (term === 'Advance Pay 6 Get 7') return "Regular Promo July 2024 - PIK 2 JMS Area - Bill in Advance Pay 6 Get 7";
            if (term === 'Advance Pay 12 Get 14') return "Regular Promo July 2024 - PIK 2 JMS Area - Bill in Advance Pay 12 Get 14";
            return "Regular Promo July 2024 - PIK 2 JMS Area";
          }
          if (area === 'Golf Island') {
            if (cat === 'Fiber Soho') {
              if (term === 'Advance Pay 6 Get 7') return "Fiber SOHO Promo - Golf Island Area - Bill in Advance Pay 6 Get 7 May 2024";
              if (term === 'Advance Pay 12 Get 14') return "Fiber SOHO Promo - Golf Island Area - Bill in Advance Pay 12 Get 14 May 2024";
              return "Fiber SOHO Promo - Golf Island Area May 2024";
            }
            if (term === 'Advance Pay 6 Get 7') return "Regular Promo Maret 2025 - Golf Island Area - Bill in Advance Pay 6 Get 7";
            if (term === 'Advance Pay 12 Get 14') return "Regular Promo Maret 2025 - Golf Island Area - Bill in Advance Pay 12 Get 14";
            return "Regular Promo Maret 2025 - Golf Island Area";
          }
          return "";
        };

        const autoNotes = getAutoNotes(newData.area, category, newData.promoTerm);
        if (autoNotes) {
          newData.catatan = autoNotes;
        }
      }
      
      if (['smartboxText', 'smartboxQty', 'routerQty', 'customQty', 'routerPrice', 'customPrice'].includes(name)) {
        const qtySBox = name === 'smartboxQty' ? parseInt(value) || 0 : parseInt(newData.smartboxQty) || 0;
        const sBox = name === 'smartboxText' ? value : newData.smartboxText;
        
        let perangkatTotal = 0;
        if (sBox && SMARTBOX_PRICES[sBox]) {
          const multiplier = qtySBox > 0 ? qtySBox : 1;
          perangkatTotal += SMARTBOX_PRICES[sBox] * multiplier;
          if (name === 'smartboxText' && !newData.smartboxQty) newData.smartboxQty = '1';
        }

        const rPrice = name === 'routerPrice' ? parseInt(value) || 0 : parseInt(newData.routerPrice) || 0;
        const rQty = name === 'routerQty' ? parseInt(value) || 0 : parseInt(newData.routerQty) || 0;
        if (rPrice > 0) perangkatTotal += rPrice * (rQty > 0 ? rQty : 1);

        const cPrice = name === 'customPrice' ? parseInt(value) || 0 : parseInt(newData.customPrice) || 0;
        const cQty = name === 'customQty' ? parseInt(value) || 0 : parseInt(newData.customQty) || 0;
        if (cPrice > 0) perangkatTotal += cPrice * (cQty > 0 ? cQty : 1);
        
        newData.biayaPerangkat = perangkatTotal.toString();
      }
      
      return newData;
    });
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const numericValue = value.replace(/[^0-9]/g, '');
    setFormData(prev => ({ ...prev, [name]: numericValue }));
  };

  useEffect(() => {
    const hargaPaket = Number(formData.biayaPaket) || 0;
    const hargaVas = Number(formData.biayaServices) || 0;
    const hargaInstalasi = Number(formData.biayaPemasangan) || 0;
    const hargaTambahan = Number(formData.biayaTambahan) || 0;
    const hargaAddons = Number(formData.biayaAddons) || 0;
    const hargaPerangkat = Number(formData.biayaPerangkat) || 0;
    const hargaLainnya = Number(formData.biayaLainnya) || 0;

    let diskonPromo = 0;
    if (formData.promo === 'Diskon 50K') diskonPromo = 50000;
    
    let instalasiAkhir = hargaInstalasi;
    if (formData.promo === 'Free Instalasi') {
      instalasiAkhir = 0; 
    }

    const subtotal = hargaPaket + hargaVas + instalasiAkhir + hargaTambahan + hargaAddons + hargaPerangkat + hargaLainnya - diskonPromo;
    const ppn = Math.max(0, Math.round(subtotal * 0.11)); 
    const total = Math.max(0, subtotal + ppn);

    setKalkulasi({ ppn, total });
  }, [formData.biayaPaket, formData.biayaServices, formData.biayaPemasangan, formData.biayaTambahan, formData.biayaAddons, formData.biayaPerangkat, formData.biayaLainnya, formData.promo]);



  const formatRupiah = (angka: number | string) => {
    if (angka === 0 || angka === '0') return 'Rp 0';
    if (!angka) return '';
    return 'Rp ' + angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  const getHari = (dateString: string) => {
    if (!dateString) return '';
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const d = new Date(dateString);
    return days[d.getDay()];
  };

  const handleVasSelectChange = (selectedOptions: any) => {
    const selectedVas = selectedOptions ? selectedOptions.map((opt: any) => opt.value) : [];
    let totalServices = 0;
    
    selectedVas.forEach((val: string) => {
      const vasItem = VAS_DATA.find(v => v.name === val);
      if (vasItem) totalServices += vasItem.price;
    });
    
    const qty = parseInt(formData.smartboxQty) || 0;
    let perangkatTotal = 0;
    if (formData.smartboxText && SMARTBOX_PRICES[formData.smartboxText]) {
      const multiplier = qty > 0 ? qty : 1;
      perangkatTotal += SMARTBOX_PRICES[formData.smartboxText] * multiplier;
    }
    const rPrice = parseInt(formData.routerPrice) || 0;
    const rQty = parseInt(formData.routerQty) || 0;
    if (rPrice > 0) perangkatTotal += rPrice * (rQty > 0 ? rQty : 1);

    const cPrice = parseInt(formData.customPrice) || 0;
    const cQty = parseInt(formData.customQty) || 0;
    if (cPrice > 0) perangkatTotal += cPrice * (cQty > 0 ? cQty : 1);
    
    setFormData(prev => ({
      ...prev,
      vas: selectedVas,
      biayaServices: totalServices.toString(),
      biayaPerangkat: perangkatTotal.toString()
    }));
  };

  const handleNext = () => {
    if (currentStep === 1) {
      if (!formData.ktp || formData.ktp.length !== 16) {
        alert("Peringatan: Nomor Identitas (KTP) harus diisi dan berjumlah tepat 16 digit angka!");
        return;
      }
    }
    if (currentStep === 3) {
      const rPrice = parseInt(formData.routerPrice) || 0;
      const rQty = parseInt(formData.routerQty) || 0;
      if ((formData.routerText || rPrice > 0) && rQty <= 0) {
        alert("Peringatan: Unit (Qty) untuk Wireless Router harus diisi minimal 1!");
        return;
      }
      
      const sQty = parseInt(formData.smartboxQty) || 0;
      if (formData.smartboxText && sQty <= 0) {
        alert("Peringatan: Unit (Qty) untuk Smartbox harus diisi minimal 1!");
        return;
      }
      
      const cPrice = parseInt(formData.customPrice) || 0;
      const cQty = parseInt(formData.customQty) || 0;
      if ((formData.customText || cPrice > 0) && cQty <= 0) {
        alert("Peringatan: Unit (Qty) untuk Custom Perangkat harus diisi minimal 1!");
        return;
      }
    }
    if (currentStep < totalSteps) {
      const nextStep = currentStep + 1;
      
      // Auto-save silently if we have at least some basic data
      if (currentStep >= 1 && (formData.namaLengkap || formData.ktp)) {
        handleSaveDraft(true);
      }
      
      setCurrentStep(nextStep);
      const url = new URL(window.location.href);
      url.searchParams.set('step', nextStep.toString());
      window.history.pushState({}, '', url);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      window.history.back();
    }
  };

  const clearSignature = () => {
    sigCanvas.current?.clear();
    setSignatureData(null);
  };

  const clearCCSignature = () => {
    ccSigCanvas.current?.clear();
    setCcSignatureData(null);
  };

  // Callback setiap kali coretan CC selesai
  const onCCSigEnd = () => {
    if (ccSigCanvas.current && !ccSigCanvas.current.isEmpty()) {
      setCcSignatureData(ccSigCanvas.current.toDataURL());
    }
  };

  // Callback setiap kali coretan TTD Utama selesai
  const onSigEnd = () => {
    if (sigCanvas.current && !sigCanvas.current.isEmpty()) {
      setSignatureData(sigCanvas.current.toDataURL());
    }
  };

  const handleSaveDraft = async (isSilent: boolean | React.MouseEvent = false) => {
    const silent = typeof isSilent === 'boolean' ? isSilent : false;
    
    if (!silent) setIsDrafting(true);
    try {
      const payload = {
        id: draftId,
        nama_lengkap: formData.namaLengkap,
        tempat_lahir: formData.tempatLahir,
        tanggal_lahir: formData.tanggalLahir,
        ktp: formData.ktp,
        jenis_kelamin: formData.jenisKelamin,
        telp_selular: formData.telpSelular,
        telp_rumah: formData.telpRumah,
        alamat: formData.alamat,
        rt: formData.rt,
        rw: formData.rw,
        kode_pos: formData.kodePos,
        status_kepemilikan: formData.statusKepemilikan,
        email: formData.email,
        paket_layanan: formData.paketLayanan,
        paket_spec: formData.paketSpec,
        vas: JSON.stringify({
          vas: formData.vas,
          routerText: formData.routerText,
          routerPrice: formData.routerPrice,
          routerQty: formData.routerQty,
          smartboxText: formData.smartboxText,
          smartboxQty: formData.smartboxQty,
          customText: formData.customText,
          customPrice: formData.customPrice,
          customQty: formData.customQty,
          densTvCheck: formData.densTvCheck,
          visionTvCheck: formData.visionTvCheck,
          addon1Check: formData.addon1Check,
          addon1Text: formData.addon1Text
        }),
        promo: formData.area,
        router_qty: Number(formData.routerQty) || 0,
        smartbox_qty: Number(formData.smartboxQty) || 0,
        username_zentry: formData.username,
        tgl_pemasangan: formData.tglPemasangan,
        waktu_pemasangan: formData.waktuPemasangan,
        homepass_id: formData.homepassId,
        titik_koordinat: formData.titikKoordinat,
        catatan: formData.catatan,
        cc_nama: formData.ccNama,
        cc_nomor: formData.ccNomor,
        cc_berlaku: formData.ccBerlaku,
        cc_bank: formData.ccBank,
        cc_wewenang: formData.ccWewenang,
        signature_base64: signatureData,
        cc_signature_base64: ccSignatureData,
        biaya_pemasangan: Number(formData.biayaPemasangan) || 0,
        biaya_paket: Number(formData.biayaPaket) || 0,
        biaya_tambahan: Number(formData.biayaTambahan) || 0,
        biaya_services: Number(formData.biayaServices) || 0,
        biaya_addons: Number(formData.biayaAddons) || 0,
        biaya_perangkat: Number(formData.biayaPerangkat) || 0,
        biaya_lainnya: Number(formData.biayaLainnya) || 0,
        biaya_administrasi: 5000,
        biaya_ppn: kalkulasi.ppn,
        biaya_total: kalkulasi.total
      };

      const res = await fetch('/api/save-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        let errMsg = "Gagal menyimpan draft";
        try {
          const errData = await res.json();
          errMsg = errData.error || errMsg;
        } catch (e) {}
        if (!silent) throw new Error(errMsg);
        else console.error(errMsg);
      }
      
      const result = await res.json();
      
      if (!silent) {
        alert("Draft berhasil disimpan! Anda bisa melanjutkannya nanti di menu Riwayat.");
      }
      
      if (!draftId && result.draftId) {
        setDraftId(result.draftId);
        const url = new URL(window.location.href);
        url.searchParams.set('draft_id', result.draftId);
        window.history.replaceState({}, '', url);
      }
    } catch (e: any) {
      if (!silent) alert("Error: " + e.message);
    } finally {
      if (!silent) setIsDrafting(false);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await handleSaveDraft(true);
      
      const payload = {
        ...formData,
        id: draftId, // Include draft id if it exists
        signature: signatureData, // ambil dari state
        ccSignature: ccSignatureData, // ambil dari state
        hariPemasangan: getHari(formData.tglPemasangan),
        biayaPemasangan: formatRupiah(formData.biayaPemasangan),
        biayaPaket: formatRupiah(formData.biayaPaket),
        biayaTambahan: formatRupiah(formData.biayaTambahan),
        biayaServices: formatRupiah(formData.biayaServices),
        biayaAddons: formatRupiah(formData.biayaAddons),
        biayaPerangkat: formatRupiah(formData.biayaPerangkat),
        biayaLainnya: formatRupiah('5000'),
        biayaPpn: formatRupiah(kalkulasi.ppn),
        biayaTotal: formatRupiah(kalkulasi.total)
      };

      const response = await fetch('/api/generate-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        let errDetails = 'Gagal generate PDF';
        try {
          const errBody = await response.json();
          if (errBody.details) errDetails = errBody.details;
        } catch(e) {}
        throw new Error(errDetails);
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Form_ZEntry_${formData.namaLengkap || 'Pelanggan'}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      
      alert('PDF berhasil di-generate dan diunduh!');

      // Set form as submitted to show the success screen with buttons
      setIsSubmitted(true);
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 100);
      
    } catch (error: any) {
      console.error(error);
      alert(`Terjadi kesalahan saat generate PDF: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleShareWa = async () => {
    const { generateWaTemplate } = await import("@/lib/waGenerator");
    const template = generateWaTemplate(formData);
    const waUrl = `https://wa.me/?text=${encodeURIComponent(template)}`;
    window.open(waUrl, '_blank');
  };

  const handleCopyText = async () => {
    const { generateWaTemplate } = await import("@/lib/waGenerator");
    const template = generateWaTemplate(formData);
    try {
      await navigator.clipboard.writeText(template);
      alert('Teks "Format Pendaftaran" berhasil disalin ke Clipboard!');
    } catch(e) {
      alert('Gagal menyalin teks. Pastikan browser Anda mengizinkan akses Clipboard.');
    }
  };

  if (isSubmitted) {
    return (
      <div className="wizard-container animate-fade-in" style={{ textAlign: 'center', padding: 'var(--spacing-xxl) 0' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '80px', height: '80px', borderRadius: '50%', backgroundColor: '#D1FAE5', color: 'var(--success)', marginBottom: 'var(--spacing-lg)' }}>
          <CheckCircle size={40} />
        </div>
        <h2 className="h2" style={{ marginBottom: 'var(--spacing-sm)' }}>Pendaftaran Berhasil!</h2>
        <p className="text-body text-muted" style={{ marginBottom: 'var(--spacing-xl)' }}>
          Dokumen PDF telah otomatis diunduh ke perangkat Anda. <br/>
          Silakan bagikan format pendaftaran ini ke grup WhatsApp.
        </p>
        
        <div className="flex flex-col gap-md" style={{ maxWidth: '400px', margin: '0 auto' }}>
          <button type="button" className="btn btn-primary" onClick={handleShareWa} style={{ width: '100%', backgroundColor: '#25D366', borderColor: '#25D366', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}>
            Kirim ke WhatsApp
          </button>
          
          <button type="button" className="btn btn-secondary" onClick={handleCopyText} style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}>
            Salin Teks Format Saja
          </button>

          <a href="/sales/history" className="btn btn-outline" style={{ width: '100%', marginTop: 'var(--spacing-md)' }}>
            Kembali ke Riwayat
          </a>
        </div>
      </div>
    );
  }

  const STEP_TITLES = ['Data Pelanggan', 'Paket & Layanan', 'Data Alamat', 'Dokumen', 'Verifikasi', 'Ringkasan'];
  const STEP_ICONS = ['👤', '📦', '📍', '📄', '🛡️', '📋'];
  const STEP_TIPS = [
    [
      'Pastikan data sesuai dengan KTP',
      'Periksa kembali NIK, nama, dan tanggal lahir',
      'Data yang benar mempercepat proses verifikasi',
      'Simpan draft jika belum selesai'
    ],
    [
      'Pilih paket yang sesuai dengan kebutuhan internet',
      'Periksa promo atau diskon yang sedang berlaku',
      'Pastikan area jangkauan (servis) sudah sesuai',
      'Tambahkan VAS jika pelanggan membutuhkan'
    ],
    [
      'Tuliskan alamat selengkap dan sedetail mungkin',
      'Jangan lupa mencantumkan RT, RW, Kode Pos, dan Kelurahan',
      'Isi koordinat atau patokan rumah agar mempermudah teknisi',
      'Pastikan nomor penanggung jawab di lokasi aktif dan bisa dihubungi'
    ],
    [
      'Unggah foto KTP asli dengan jelas dan tidak buram',
      'Pastikan seluruh sudut dokumen masuk ke dalam frame',
      'Format file yang didukung: JPG, PNG, atau PDF',
      'Periksa kembali lampiran sebelum melanjutkan ke tahap verifikasi'
    ],
    [
      'Periksa ringkasan paket dan biaya yang telah dipilih',
      'Pastikan pelanggan telah membaca syarat & ketentuan',
      'Konfirmasi kembali total biaya bulanan kepada pelanggan',
      'Lakukan tanda tangan persetujuan kontak darurat jika diperlukan'
    ],
    [
      'Pastikan tanda tangan pelanggan jelas dan berada di dalam kotak',
      'Tanda tangan Leader/Sales akan terlampir secara otomatis',
      'Tekan tombol Simpan & Generate PDF untuk menghasilkan dokumen resmi',
      'Bagikan ringkasan PDF ke grup WhatsApp atau unduh arsipnya'
    ]
  ];

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 320px', gap: '28px', alignItems: 'start' }}>
      
      {/* Left Column: Progress Bar + Form Card */}
      <div style={{ minWidth: 0 }}>
        
        {/* Progress Indicator */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '28px', overflowX: 'auto', paddingBottom: '12px', gap: '8px' }}>
          {[1, 2, 3, 4, 5, 6].map((step, idx) => {
            const isActive = step === currentStep;
            const isDone = step < currentStep;
            return (
              <React.Fragment key={step}>
                <div 
                  onClick={() => isDone && setCurrentStep(step)}
                  style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '10px', 
                    cursor: isDone ? 'pointer' : 'default',
                    flexShrink: 0
                  }}
                >
                  <div style={{
                    width: '32px', height: '32px', borderRadius: '50%',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    backgroundColor: isDone ? '#10B981' : isActive ? '#2563EB' : '#F1F5F9',
                    color: isDone || isActive ? 'white' : '#94A3B8',
                    fontWeight: 700, fontSize: '0.85rem',
                    border: isDone || isActive ? 'none' : '1px solid #CBD5E1',
                    boxShadow: isActive ? '0 4px 10px -2px rgba(37, 99, 235, 0.4)' : 'none',
                    transition: 'all 0.3s ease'
                  }}>
                    {isDone ? <CheckCircle size={16} /> : step}
                  </div>
                  <span style={{
                    fontSize: '0.85rem',
                    fontWeight: isActive || isDone ? 700 : 500,
                    color: isActive ? '#2563EB' : isDone ? '#0F172A' : '#94A3B8',
                    whiteSpace: 'nowrap'
                  }}>
                    {STEP_TITLES[idx]}
                  </span>
                </div>
                {step < 6 && (
                  <div style={{ flex: 1, minWidth: '15px', height: '2px', backgroundColor: isDone ? '#10B981' : '#E2E8F0', margin: '0 6px' }} />
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* White Card for Current Step Form */}
        <div style={{ background: '#FFFFFF', border: '1px solid #E2E8F0', borderRadius: '20px', padding: '32px', boxShadow: '0 10px 30px -5px rgba(0, 0, 0, 0.04)' }}>
          
          {/* Step Header */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginBottom: '28px', borderBottom: '1px solid #F1F5F9', paddingBottom: '20px' }}>
            <div style={{ width: '46px', height: '46px', borderRadius: '14px', background: '#EFF6FF', color: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.4rem', flexShrink: 0 }}>
              {STEP_ICONS[currentStep - 1]}
            </div>
            <h2 style={{ margin: 0, fontSize: '1.4rem', fontWeight: 800, color: '#0F172A' }}>
              {currentStep}. {STEP_TITLES[currentStep - 1]}
            </h2>
          </div>

          {/* Form Content Area */}
          <div style={{ minHeight: '380px' }}>
            
            {/* STEP 1 */}
            {currentStep === 1 && (
              <div className="animate-fade-in">
                {/* OCR Banner Card */}
                <div style={{ background: '#F8FAFC', border: '1.5px dashed #CBD5E1', borderRadius: '16px', padding: '24px', marginBottom: '28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '20px', position: 'relative', overflow: 'hidden' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 700, color: '#0F172A', fontSize: '0.95rem', marginBottom: '12px' }}>
                      Auto-isi dengan Scan KTP (BETA) <span style={{ color: '#2563EB', fontSize: '1rem', cursor: 'pointer' }}>ⓘ</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
                      <button type="button" onClick={() => fileInputRef.current?.click()} disabled={isOcring} style={{ background: '#EFF6FF', border: '1px solid #3B82F6', color: '#2563EB', padding: '8px 16px', borderRadius: '8px', fontWeight: 700, fontSize: '0.85rem', display: 'inline-flex', alignItems: 'center', gap: '8px', cursor: 'pointer', transition: 'all 0.2s' }}>
                        <Upload size={16} /> {isOcring ? 'Memindai KTP...' : 'Pilih File'}
                      </button>
                      <span style={{ fontSize: '0.85rem', color: '#64748B', fontWeight: 500 }}>
                        {fileInputRef.current?.files?.[0]?.name || 'Tidak ada file yang dipilih'}
                      </span>
                      <input ref={fileInputRef} type="file" accept="image/*" capture="environment" onChange={handleOcrUpload} disabled={isOcring} style={{ display: 'none' }} />
                    </div>
                    <div style={{ fontSize: '0.8rem', color: '#334155', fontWeight: 500 }}>Ambil foto KTP untuk mengisi NIK, Nama, dan TTL secara otomatis.</div>
                    <div style={{ fontSize: '0.75rem', color: '#94A3B8', fontStyle: 'italic', marginTop: '2px' }}>Foto tidak disimpan, sistem hanya membaca teksnya sesaat.</div>
                  </div>

                  {/* 3D Illustration Graphic for KTP + Camera */}
                  <div style={{ position: 'relative', width: '130px', height: '80px', display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none', marginRight: '10px' }}>
                    <div style={{ width: '110px', height: '70px', background: 'linear-gradient(135deg, #FFFFFF 0%, #EFF6FF 100%)', borderRadius: '10px', border: '2px solid #BFDBFE', boxShadow: '0 8px 20px rgba(59, 130, 246, 0.15)', padding: '10px', display: 'flex', gap: '8px', alignItems: 'center', transform: 'rotate(-3deg)' }}>
                      <div style={{ width: '28px', height: '34px', background: '#DBEAFE', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem' }}>👤</div>
                      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '6px' }}>
                        <div style={{ width: '80%', height: '6px', background: '#3B82F6', borderRadius: '3px' }} />
                        <div style={{ width: '100%', height: '4px', background: '#93C5FD', borderRadius: '2px' }} />
                        <div style={{ width: '60%', height: '4px', background: '#BFDBFE', borderRadius: '2px' }} />
                      </div>
                    </div>
                    <div style={{ position: 'absolute', right: '-5px', bottom: '-5px', width: '36px', height: '36px', background: '#2563EB', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', boxShadow: '0 4px 10px rgba(37, 99, 235, 0.4)', border: '2px solid white' }}>
                      <span style={{ fontSize: '1rem' }}>📷</span>
                    </div>
                  </div>
                </div>

            <div className="input-group">
              <label className="input-label">Nama Lengkap</label>
              <input type="text" name="namaLengkap" className="input-field" value={formData.namaLengkap} onChange={handleChange} />
            </div>
            
            <div className="flex stack-mobile gap-md">
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Tempat Lahir</label>
                <input type="text" name="tempatLahir" className="input-field" value={formData.tempatLahir} onChange={handleChange} />
              </div>
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Tanggal Lahir</label>
                <input type="date" name="tanggalLahir" className="input-field" value={formData.tanggalLahir} onChange={handleChange} />
              </div>
            </div>

            <div className="flex stack-mobile gap-md">
              <div className="input-group" style={{ flex: 2 }}>
                <label className="input-label">Nomor Identitas (KTP)</label>
                <input type="text" name="ktp" className="input-field" maxLength={16} value={formData.ktp} onChange={handleChange} placeholder="Harus 16 Digit" />
                {formData.ktp.length > 0 && formData.ktp.length !== 16 && (
                  <span style={{ color: 'red', fontSize: '12px' }}>KTP harus 16 digit ({formData.ktp.length}/16)</span>
                )}
              </div>
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Jenis Kelamin</label>
                <select name="jenisKelamin" className="input-field" value={formData.jenisKelamin} onChange={handleChange}>
                  <option value="">Pilih...</option>
                  <option value="Pria">Pria</option>
                  <option value="Wanita">Wanita</option>
                </select>
              </div>
            </div>

            <div className="flex stack-mobile gap-md">
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Telepon Selular</label>
                <input type="tel" name="telpSelular" className="input-field" value={formData.telpSelular} onChange={handleChange} />
              </div>
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Telepon Rumah (Opsional)</label>
                <input type="tel" name="telpRumah" className="input-field" value={formData.telpRumah} onChange={handleChange} />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2 */}
        {currentStep === 2 && (
          <div className="animate-fade-in">
            <div className="input-group">
              <label className="input-label">Alamat Lengkap</label>
              <textarea name="alamat" className="input-field" rows={3} value={formData.alamat} onChange={handleChange}></textarea>
            </div>

            <div className="flex stack-mobile gap-md">
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">RT</label>
                <input type="text" name="rt" className="input-field" maxLength={3} value={formData.rt} onChange={handleChange} />
              </div>
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">RW</label>
                <input type="text" name="rw" className="input-field" maxLength={3} value={formData.rw} onChange={handleChange} />
              </div>
              <div className="input-group" style={{ flex: 2 }}>
                <label className="input-label">Kode Pos</label>
                <input type="text" name="kodePos" className="input-field" maxLength={5} value={formData.kodePos} onChange={handleChange} />
              </div>
            </div>

            <div className="input-group">
              <label className="input-label" style={{ marginBottom: 'var(--spacing-sm)' }}>Status Kepemilikan</label>
              <div className="flex stack-mobile gap-md">
                <label className="flex items-center gap-sm" style={{ cursor: 'pointer' }}>
                  <input type="radio" name="statusKepemilikan" value="Pemilik" checked={formData.statusKepemilikan === 'Pemilik'} onChange={handleChange} /> Pemilik
                </label>
                <label className="flex items-center gap-sm" style={{ cursor: 'pointer' }}>
                  <input type="radio" name="statusKepemilikan" value="Penyewa" checked={formData.statusKepemilikan === 'Penyewa'} onChange={handleChange} /> Penyewa
                </label>
              </div>
            </div>

            <div className="input-group">
              <label className="input-label">Alamat Email Pelanggan</label>
              <input type="email" name="email" className="input-field" value={formData.email} onChange={handleChange} />
            </div>
          </div>
        )}
        
        {/* STEP 3 */}
        {currentStep === 3 && (
          <div className="animate-fade-in">
            {(() => {
              const areaData = PACKAGES_DATA[formData.area] || {};
              const categoryMap: Record<string, string> = { 'Fiber': 'Fiber Reguler', 'Safe': 'Fiber Safe', 'Soho': 'Fiber Soho' };
              const selectedCategoryName = categoryMap[formData.paketLayanan];
              
              let availableTerms: string[] = [];
              if (areaData[selectedCategoryName]) {
                availableTerms = areaData[selectedCategoryName].terms || [];
              } else {
                availableTerms = Array.from(new Set(Object.values(areaData).flatMap((cat: any) => cat.terms || []))) as string[];
              }

              return (
                <>
                  <div className="flex stack-mobile gap-md" style={{ marginBottom: 'var(--spacing-md)' }}>
                    <div className="input-group" style={{ flex: 1 }}>
                      <label className="input-label">Servis</label>
                      <select name="area" className="input-field" value={formData.area} onChange={handleChange}>
                        {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
                      </select>
                    </div>
                    <div className="input-group" style={{ flex: 1 }}>
                      <label className="input-label">Promo</label>
                      <select name="promoTerm" className="input-field" value={formData.promoTerm} onChange={handleChange}>
                        {availableTerms.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="input-group">
                    <label className="input-label" style={{ marginBottom: 'var(--spacing-sm)' }}>Paket Layanan Utama</label>
                    <div className="flex-col gap-sm">
                      {['Fiber', 'Safe', 'Soho'].map((cat) => {
                        const categoryMap: Record<string, string> = { 'Fiber': 'Fiber Reguler', 'Safe': 'Fiber Safe', 'Soho': 'Fiber Soho' };
                        const categoryName = categoryMap[cat];
                        const hasCategory = areaData && areaData[categoryName];
                        
                        if (!hasCategory) return null; // Hide if not available in this area
                        
                        return (
                          <div key={cat} className="card flex items-center gap-md" style={{ padding: 'var(--spacing-md)', borderColor: formData.paketLayanan === cat ? 'var(--solasi-blue)' : 'var(--border-color)' }}>
                            <input type="radio" name="paketLayanan" value={cat} checked={formData.paketLayanan === cat} onChange={handleChange} />
                            <div style={{ fontWeight: 600, width: '150px' }}>
                              {cat === 'Fiber' ? 'CBN Fiber' : cat === 'Safe' ? 'CBN Fiber Safe' : 'CBN Fiber Soho'}
                            </div>
                            {formData.paketLayanan === cat && (
                              <select name="paketSpec" className="input-field" value={formData.paketSpec} onChange={handleChange} style={{ flex: 1 }}>
                                <option value="">-- Pilih Kecepatan --</option>
                                {areaData[categoryName].speeds.map((speed: string) => (
                                  <option key={speed} value={speed}>{speed}</option>
                                ))}
                              </select>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </>
              );
            })()}

            <div className="input-group" style={{ marginTop: 'var(--spacing-xl)' }}>
              <label className="input-label" style={{ marginBottom: 'var(--spacing-sm)' }}>VAS (Value Added Service) - Bisa diketik untuk mencari</label>
              <Select
                isMulti
                name="vas"
                options={[
                  {
                    label: 'VAS Berbayar',
                    options: VAS_DATA.filter(v => v.category === 'Berbayar').map(v => ({ value: v.name, label: `${v.name} (+Rp ${v.price.toLocaleString('id-ID')})` }))
                  },
                  {
                    label: 'VAS Free',
                    options: VAS_DATA.filter(v => v.category === 'Free').map(v => ({ value: v.name, label: `${v.name} (Gratis)` }))
                  }
                ]}
                className="basic-multi-select"
                classNamePrefix="select"
                value={formData.vas.map(v => {
                  const vasItem = VAS_DATA.find(item => item.name === v);
                  if (!vasItem) return { value: v, label: v };
                  return {
                    value: v,
                    label: vasItem.category === 'Free' ? `${v} (Gratis)` : `${v} (+Rp ${vasItem.price.toLocaleString('id-ID')})`
                  };
                })}
                onChange={handleVasSelectChange}
                placeholder="Pilih VAS..."
                styles={{
                  control: (base) => ({
                    ...base,
                    borderColor: 'var(--border-color)',
                    padding: '2px',
                    borderRadius: '8px'
                  })
                }}
              />
            </div>

            <div className="input-group" style={{ marginTop: 'var(--spacing-xl)' }}>
              <label className="input-label" style={{ marginBottom: 'var(--spacing-sm)' }}>Perangkat Tambahan</label>
              <div className="flex stack-mobile gap-md" style={{ marginBottom: 'var(--spacing-md)' }}>
                <label className="flex items-center gap-sm" style={{ minWidth: '100px', fontSize: '0.85rem', lineHeight: '1.2' }}>Wireless Router</label>
                <input type="text" name="routerText" className="input-field" placeholder="Keterangan (Merek/Tipe)..." value={formData.routerText} onChange={handleChange} style={{ flex: 1, fontSize: '0.85rem' }} />
                <input type="text" name="routerPrice" className="input-field" placeholder="Rp Harga" style={{ width: '100px', fontSize: '0.85rem' }} value={formData.routerPrice} onChange={handleNumberChange} />
                <input type="number" name="routerQty" className="input-field" placeholder="Unit" style={{ width: '70px', fontSize: '0.85rem' }} value={formData.routerQty} onChange={handleChange} />
              </div>
              <div className="flex stack-mobile gap-md" style={{ marginBottom: 'var(--spacing-md)' }}>
                <label className="flex items-center gap-sm" style={{ minWidth: '100px', fontSize: '0.85rem', lineHeight: '1.2' }}>Smartbox</label>
                <select name="smartboxText" className="input-field" value={formData.smartboxText} onChange={handleChange} style={{ flex: 1, fontSize: '0.85rem' }}>
                  <option value="">-- Pilih --</option>
                  <option value="DensTV STB">DensTV STB (Rp 45.000)</option>
                  <option value="DensTV STB V.3">DensTV STB V.3 (Rp 55.000)</option>
                  <option value="DensTV STB V.3 (Area JMS)">DensTV STB V.3 Area JMS (Rp 60.000)</option>
                </select>
                <input type="number" name="smartboxQty" className="input-field" placeholder="Unit" style={{ width: '70px', fontSize: '0.85rem' }} value={formData.smartboxQty} onChange={handleChange} />
              </div>
              <div className="flex stack-mobile gap-md" style={{ marginBottom: 'var(--spacing-md)' }}>
                <label className="flex items-center gap-sm" style={{ minWidth: '100px', fontSize: '0.85rem', lineHeight: '1.2' }}>Custom Perangkat</label>
                <input type="text" name="customText" className="input-field" placeholder="Nama & Ket Perangkat..." value={formData.customText} onChange={handleChange} style={{ flex: 1, fontSize: '0.85rem' }} />
                <input type="text" name="customPrice" className="input-field" placeholder="Rp Harga" style={{ width: '100px', fontSize: '0.85rem' }} value={formData.customPrice} onChange={handleNumberChange} />
                <input type="number" name="customQty" className="input-field" placeholder="Unit" style={{ width: '70px', fontSize: '0.85rem' }} value={formData.customQty} onChange={handleChange} />
              </div>
            </div>

            <div className="input-group" style={{ marginTop: 'var(--spacing-xl)' }}>
              <label className="input-label" style={{ marginBottom: 'var(--spacing-sm)' }}>Paket Add-On TV (Opsional)</label>
              
              <div className="flex stack-mobile gap-md">
                <label className="flex items-center gap-sm" style={{ fontSize: '0.85rem', lineHeight: '1.2', flex: 1 }}>
                  <input type="checkbox" name="densTvCheck" checked={formData.densTvCheck} onChange={handleChange} style={{ flexShrink: 0 }} /> 
                  <span style={{ whiteSpace: 'normal', wordBreak: 'break-word' }}>Dens.TV+ Apps</span>
                </label>
                <label className="flex items-center gap-sm" style={{ fontSize: '0.85rem', lineHeight: '1.2', flex: 1 }}>
                  <input type="checkbox" name="visionTvCheck" checked={formData.visionTvCheck} onChange={handleChange} style={{ flexShrink: 0 }} /> 
                  <span style={{ whiteSpace: 'normal', wordBreak: 'break-word' }}>Vision+ Premium Sports</span>
                </label>
              </div>

              <div className="flex items-center gap-md" style={{ marginTop: 'var(--spacing-sm)' }}>
                <label className="flex items-center gap-sm" style={{ fontSize: '0.85rem', lineHeight: '1.2', minWidth: '130px' }}>
                  <input type="checkbox" name="addon1Check" checked={formData.addon1Check} onChange={handleChange} style={{ flexShrink: 0 }} /> 
                  <span style={{ whiteSpace: 'normal', wordBreak: 'break-word' }}>Lainnya (Custom)</span>
                </label>
                <input type="text" name="addon1Text" className="input-field" placeholder="Contoh: Dramaflix +50Mbps..." value={formData.addon1Text} onChange={handleChange} style={{ flex: 1, fontSize: '0.85rem' }} />
              </div>
            </div>
          </div>
        )}

        {/* STEP 4 */}
        {currentStep === 4 && (
          <div className="animate-fade-in">
            <div className="input-group">
              <label className="input-label">Username ZEntry</label>
              <div className="flex items-center">
                <input type="text" name="username" className="input-field" style={{ flex: 1 }} value={formData.username} onChange={handleChange} />
              </div>
            </div>

            <div className="flex stack-mobile gap-md">
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Homepass ID</label>
                <input type="text" name="homepassId" className="input-field" value={formData.homepassId} onChange={handleChange} placeholder="Contoh: CBN-12345" />
              </div>
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Titik Koordinat (Lat, Long)</label>
                <input type="text" name="titikKoordinat" className="input-field" value={formData.titikKoordinat} onChange={handleChange} placeholder="-6.2088, 106.8456" />
              </div>
            </div>

            <div className="flex stack-mobile gap-md mt-md">
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Tanggal Pemasangan</label>
                <input type="date" name="tglPemasangan" className="input-field" value={formData.tglPemasangan} onChange={handleChange} />
              </div>
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Hari (Otomatis)</label>
                <input type="text" className="input-field" value={getHari(formData.tglPemasangan)} readOnly style={{ backgroundColor: '#f0f0f0' }} />
              </div>
              <div className="input-group" style={{ flex: 1 }}>
                <label className="input-label">Waktu Pemasangan</label>
                <select name="waktuPemasangan" className="input-field" value={formData.waktuPemasangan} onChange={handleChange}>
                  <option value="">Pilih...</option>
                  <option value="09.00-11.00">09.00 - 11.00</option>
                  <option value="11.00-13.00">11.00 - 13.00</option>
                  <option value="13.00-15.00">13.00 - 15.00</option>
                  <option value="15.00-17.00">15.00 - 17.00</option>
                </select>
              </div>
            </div>

            <div className="input-group" style={{ marginTop: 'var(--spacing-md)' }}>
              <label className="input-label">Catatan (Notes)</label>
              <textarea name="catatan" className="input-field" rows={4} value={formData.catatan} onChange={handleChange} placeholder="Masukkan catatan opsional..."></textarea>
            </div>
          </div>
        )}

        {/* STEP 5 */}
        {currentStep === 5 && (
          <div className="animate-fade-in">
            <div className="flex stack-mobile gap-lg">
              <div style={{ flex: 1, minWidth: 0 }}>
                <h4 className="text-large" style={{ marginBottom: 'var(--spacing-md)', color: 'var(--solasi-blue)' }}>Kartu Kredit</h4>
                
                <div className="input-group">
                  <label className="input-label">Nama Pada Kartu</label>
                  <input type="text" name="ccNama" className="input-field" value={formData.ccNama} onChange={handleChange} />
                </div>
                <div className="input-group">
                  <label className="input-label">Nomor Kartu</label>
                  <input type="text" name="ccNomor" className="input-field" value={formData.ccNomor} onChange={handleChange} />
                </div>
                <div className="flex stack-mobile gap-md">
                  <div className="input-group" style={{ flex: 1, minWidth: 0 }}>
                    <label className="input-label">Masa Berlaku (MM/YYYY)</label>
                    <input type="text" name="ccBerlaku" className="input-field" placeholder="01/2028" value={formData.ccBerlaku} onChange={handleChange} />
                  </div>
                  <div className="input-group" style={{ flex: 1, minWidth: 0 }}>
                    <label className="input-label">Nama Bank</label>
                    <input type="text" name="ccBank" className="input-field" value={formData.ccBank} onChange={handleChange} />
                  </div>
                </div>
                
                <label className="flex items-start gap-sm mt-md" style={{ cursor: 'pointer', fontSize: '13px', lineHeight: '1.4' }}>
                  <input type="checkbox" name="ccWewenang" checked={formData.ccWewenang} onChange={handleChange} style={{ marginTop: '3px', flexShrink: 0 }} />
                  <span style={{ wordBreak: 'break-word' }}>
                    Saya memberikan wewenang kepada PT. Cyberindo Aditama untuk melakukan penagihan melalui kartu kredit saya untuk segala biaya CBN yang saya gunakan selama masa berlangganan.
                    <br/><i style={{ color: 'var(--text-muted)' }}>I authorize PT. Cyberindo Aditama to debit my credit card for all my CBN expenses during subscription period.</i>
                  </span>
                </label>

                {/* TANDA TANGAN KARTU KREDIT */}
                <div style={{ marginTop: 'var(--spacing-lg)' }}>
                  <label className="input-label">Tanda Tangan Pemegang Kartu</label>
                  <div style={{ border: '2px dashed var(--border-color)', borderRadius: 'var(--radius-lg)', backgroundColor: 'var(--bg-color)', overflow: 'hidden' }}>
                    <SignatureCanvas 
                      ref={ccSigCanvas}
                      onEnd={onCCSigEnd}
                      clearOnResize={false}
                      canvasProps={{
                        className: 'signature-canvas',
                        style: { width: '100%', height: '120px', cursor: 'crosshair', touchAction: 'none' }
                      }} 
                    />
                  </div>
                  <div className="flex justify-end" style={{ marginTop: '8px' }}>
                    <button className="btn" style={{ padding: '4px 8px', fontSize: '12px', border: '1px solid var(--border-color)' }} onClick={clearCCSignature}>Hapus Tanda Tangan CC</button>
                  </div>
                  {ccSignatureData && <span style={{fontSize: '12px', color: 'green', display: 'block', textAlign: 'right', marginTop: '4px'}}>✓ Tersimpan</span>}
                </div>
              </div>

              <div style={{ flex: 1, minWidth: 0 }}>
                <h4 className="text-large" style={{ marginBottom: 'var(--spacing-md)', color: 'var(--solasi-blue)' }}>Rincian Biaya (Auto-Kalkulasi)</h4>
                
                <div className="flex flex-col gap-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-small">Biaya Pemasangan</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted">Rp</span>
                      <input type="text" name="biayaPemasangan" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', transition: 'all 0.2s' }} value={formatRupiah(formData.biayaPemasangan).replace('Rp ', '')} onChange={handleNumberChange} placeholder="0" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-small">Biaya Paket</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted">Rp</span>
                      <input type="text" name="biayaPaket" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', transition: 'all 0.2s' }} value={formatRupiah(formData.biayaPaket).replace('Rp ', '')} onChange={handleNumberChange} placeholder="0" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-small">Biaya Tambahan</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted">Rp</span>
                      <input type="text" name="biayaTambahan" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', transition: 'all 0.2s' }} value={formatRupiah(formData.biayaTambahan).replace('Rp ', '')} onChange={handleNumberChange} placeholder="0" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-small">Biaya Services (VAS)</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted">Rp</span>
                      <input type="text" name="biayaServices" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', transition: 'all 0.2s' }} value={formatRupiah(formData.biayaServices).replace('Rp ', '')} onChange={handleNumberChange} placeholder="0" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-small">Biaya Add Ons</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted">Rp</span>
                      <input type="text" name="biayaAddons" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', transition: 'all 0.2s' }} value={formatRupiah(formData.biayaAddons).replace('Rp ', '')} onChange={handleNumberChange} placeholder="0" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-small">Biaya Perangkat</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted">Rp</span>
                      <input type="text" name="biayaPerangkat" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', transition: 'all 0.2s' }} value={formatRupiah(formData.biayaPerangkat).replace('Rp ', '')} onChange={handleNumberChange} placeholder="0" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-small">Biaya Lainnya</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted">Rp</span>
                      <input type="text" name="biayaLainnya" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', transition: 'all 0.2s', backgroundColor: '#f0f0f0' }} value="5.000" readOnly />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-small">PPN 11% (Auto)</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted">Rp</span>
                      <input type="text" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', backgroundColor: '#f0f0f0' }} value={formatRupiah(kalkulasi.ppn).replace('Rp ', '')} readOnly />
                    </div>
                  </div>
                  <hr style={{ margin: '8px 0', borderColor: 'var(--border-color)' }} />
                  <div className="flex items-center justify-between" style={{ fontWeight: 'bold' }}>
                    <span>TOTAL (Auto)</span>
                    <div className="flex items-center gap-sm">
                      <span className="text-muted" style={{ fontWeight: 'bold' }}>Rp</span>
                      <input type="text" className="input-field" style={{ width: '120px', padding: '4px', textAlign: 'right', fontWeight: 'bold', backgroundColor: '#e6f7ff', borderColor: 'var(--solasi-blue)', color: 'var(--solasi-blue)' }} value={formatRupiah(kalkulasi.total).replace('Rp ', '')} readOnly />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 6 */}
        {currentStep === 6 && (
          <div className="animate-fade-in">
            <p className="text-muted" style={{ marginBottom: 'var(--spacing-sm)' }}>Silakan tanda tangan di dalam kotak di bawah ini.</p>
            <div style={{ border: '2px dashed var(--border-color)', borderRadius: 'var(--radius-lg)', backgroundColor: 'var(--bg-color)', overflow: 'hidden' }}>
              <SignatureCanvas 
                ref={sigCanvas}
                onEnd={onSigEnd}
                clearOnResize={false}
                canvasProps={{
                  className: 'signature-canvas',
                  style: { width: '100%', height: '200px', cursor: 'crosshair', touchAction: 'none' }
                }} 
              />
            </div>
            <div className="flex justify-end" style={{ marginTop: 'var(--spacing-sm)' }}>
              <button className="btn btn-secondary" onClick={clearSignature}>Hapus & Ulangi</button>
            </div>
            {signatureData && <span style={{fontSize: '12px', color: 'green', display: 'block', textAlign: 'right'}}>✓ Tersimpan</span>}
          </div>
        )}
          </div>

          {/* Navigation Buttons */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '36px', paddingTop: '24px', borderTop: '1px solid #F1F5F9' }}>
            <button type="button" onClick={handlePrev} disabled={currentStep === 1 || isSubmitting || isDrafting} style={{ background: 'transparent', border: '1px solid #E2E8F0', padding: '10px 20px', borderRadius: '10px', fontWeight: 700, fontSize: '0.9rem', color: '#0F172A', display: 'flex', alignItems: 'center', gap: '8px', cursor: currentStep === 1 ? 'not-allowed' : 'pointer', opacity: currentStep === 1 ? 0.5 : 1, transition: 'all 0.2s' }}>
              ← Kembali
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <button type="button" onClick={handleSaveDraft} disabled={isSubmitting || isDrafting} style={{ background: 'transparent', border: '1px solid #CBD5E1', padding: '10px 20px', borderRadius: '10px', fontWeight: 700, fontSize: '0.9rem', color: '#0F172A', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', transition: 'all 0.2s' }}>
                <Save size={16} /> {isDrafting ? 'Menyimpan...' : 'Simpan Draft'}
              </button>
              {currentStep < totalSteps ? (
                <button type="button" onClick={handleNext} disabled={isSubmitting || isDrafting} style={{ background: '#2563EB', border: 'none', padding: '10px 24px', borderRadius: '10px', fontWeight: 700, fontSize: '0.9rem', color: 'white', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(37, 99, 235, 0.3)', transition: 'all 0.2s' }}>
                  Selanjutnya →
                </button>
              ) : (
                <button type="button" onClick={handleSubmit} disabled={isSubmitting || isDrafting} style={{ background: '#10B981', border: 'none', padding: '10px 24px', borderRadius: '10px', fontWeight: 700, fontSize: '0.9rem', color: 'white', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)', transition: 'all 0.2s' }}>
                  {isSubmitting ? 'Memproses PDF...' : 'Simpan & Generate PDF →'}
                </button>
              )}
            </div>
          </div>
        </div>

      </div>

      {/* Right Column: Progress & Tips Widgets */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', position: 'sticky', top: '24px' }}>
        
        {/* Widget 1: PROGRES PENGISIAN */}
        <div style={{ background: '#FFFFFF', border: '1px solid #E2E8F0', borderRadius: '20px', padding: '24px', boxShadow: '0 10px 30px -5px rgba(0, 0, 0, 0.04)' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', letterSpacing: '0.5px', marginBottom: '16px' }}>PROGRES PENGISIAN</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            
            {/* Donut Progress Circle */}
            <div style={{ position: 'relative', width: '70px', height: '70px', flexShrink: 0 }}>
              <svg viewBox="0 0 36 36" style={{ width: '100%', height: '100%', transform: 'rotate(-90deg)' }}>
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#F1F5F9"
                  strokeWidth="3.5"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#2563EB"
                  strokeWidth="3.5"
                  strokeDasharray={`${Math.round((currentStep / 6) * 100)}, 100`}
                  strokeLinecap="round"
                />
              </svg>
              <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', fontWeight: 800, fontSize: '0.85rem', color: '#0F172A' }}>
                {Math.round((currentStep / 6) * 100)}%
              </div>
            </div>

            <div>
              <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#2563EB' }}>Langkah {currentStep} dari 6</div>
              <div style={{ fontSize: '1rem', fontWeight: 800, color: '#0F172A', margin: '2px 0' }}>{STEP_TITLES[currentStep - 1]}</div>
              <div style={{ fontSize: '0.7rem', color: '#64748B', lineHeight: 1.3 }}>Lengkapi data dengan benar untuk melanjutkan</div>
            </div>
          </div>
        </div>

        {/* Widget 2: TIPS PENGISIAN */}
        <div style={{ background: '#FFFFFF', border: '1px solid #E2E8F0', borderRadius: '20px', padding: '24px', boxShadow: '0 10px 30px -5px rgba(0, 0, 0, 0.04)', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: '360px', position: 'relative', overflow: 'hidden' }}>
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', letterSpacing: '0.5px', marginBottom: '16px' }}>TIPS PENGISIAN</div>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {(STEP_TIPS[currentStep - 1] || STEP_TIPS[0]).map((tip, idx) => (
                <li key={idx} style={{ display: 'flex', alignItems: 'flex-start', gap: '10px', fontSize: '0.825rem', color: '#334155', lineHeight: 1.4, fontWeight: 500 }}>
                  <div style={{ width: '18px', height: '18px', borderRadius: '50%', background: '#EFF6FF', color: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: '1px' }}>
                    <CheckCircle size={12} strokeWidth={3} />
                  </div>
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* 3D Illustration Graphic at bottom of Tips */}
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: '28px', pointerEvents: 'none' }}>
            <div style={{ position: 'relative', width: '140px', height: '130px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {/* Soft Blue Document */}
              <div style={{ width: '100px', height: '110px', background: 'linear-gradient(135deg, #EFF6FF 0%, #DBEAFE 100%)', borderRadius: '12px', border: '2px solid #BFDBFE', transform: 'rotate(-6deg)', boxShadow: '0 10px 20px rgba(59, 130, 246, 0.15)', padding: '14px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <div style={{ width: '40%', height: '8px', background: '#93C5FD', borderRadius: '4px' }} />
                <div style={{ width: '80%', height: '6px', background: '#BFDBFE', borderRadius: '3px' }} />
                <div style={{ width: '70%', height: '6px', background: '#BFDBFE', borderRadius: '3px' }} />
                <div style={{ width: '60%', height: '6px', background: '#BFDBFE', borderRadius: '3px', marginTop: '8px' }} />
              </div>
              {/* Shield Checkmark Overlay */}
              <div style={{ position: 'absolute', right: '10px', bottom: '5px', width: '56px', height: '62px', background: 'linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%)', borderRadius: '16px 16px 28px 28px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', boxShadow: '0 8px 16px rgba(29, 78, 216, 0.4)', border: '2px solid white', transform: 'rotate(6deg)' }}>
                <CheckCircle size={30} strokeWidth={2.5} />
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
