import React from 'react';

export default function Footer() {
  return (
    <footer style={{
      textAlign: 'center',
      padding: 'var(--spacing-md)',
      fontSize: '0.85rem',
      color: 'var(--text-muted)',
      borderTop: '1px solid var(--border-color)',
      marginTop: 'auto',
      backgroundColor: 'transparent'
    }}>
      <p style={{ margin: 0 }}>
        &copy; 2026 ZEntry. All rights reserved. Developed by{' '}
        <a href="https://www.linkedin.com/in/mochammad-ikhsan-/" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--solasi-blue)', textDecoration: 'none', fontWeight: 500 }}>Icun</a>,{' '}
        <a href="https://www.linkedin.com/in/haramain-rabbany/" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--solasi-blue)', textDecoration: 'none', fontWeight: 500 }}>Haramain</a>,{' '}
        <a href="https://www.linkedin.com/in/rofifawwaz/" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--solasi-blue)', textDecoration: 'none', fontWeight: 500 }}>Fawwaz</a>, and{' '}
        <a href="https://www.linkedin.com/in/alnandarafi/" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--solasi-blue)', textDecoration: 'none', fontWeight: 500 }}>Rafi</a>{' '}
        at Zyntaxera
      </p>
    </footer>
  );
}
