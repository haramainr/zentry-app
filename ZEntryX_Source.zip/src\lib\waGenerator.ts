export const generateWaTemplate = (formData: any) => {
  const serviceText = formData.paketLayanan === 'Fiber' 
    ? `Fiber ${formData.paketSpec || ''}`
    : formData.paketLayanan === 'Safe' 
      ? `Safe ${formData.paketSpec || ''}`
      : `Pro ${formData.paketSpec || ''}`;

  return `Format Pendaftaran

Nama : ${formData.namaLengkap || ''}
NIK : ${formData.ktp || ''}
Tgl Lahir :${formData.tanggalLahir || ''}
Telp 1 : ${formData.telpSelular || ''}
Telp 2 : ${formData.telpRumah || '**'}
Building Status : ${formData.statusKepemilikan || 'Pemilik'}
----------------------------------------------------------
Username :${formData.username || ''}
Service : ${serviceText.trim()}
Email : ${formData.email || '**'}
Installation Date:${formData.tglPemasangan || ''}
Promo : ${formData.catatan || formData.promoTerm || '**'}
STB :${formData.smartboxQty || '**'}
====================

Home ID : ${formData.homepassId || ''}
Alamat : ${formData.alamat || ''} RT${formData.rt || ''} RW${formData.rw || ''}
${formData.kodePos || ''}

Tikor : ${formData.titikKoordinat || ''}

CAE : ${formData.caeName || '[Ketik Nama Anda]'}
TL : ${formData.tlName || '[Ketik Nama TL Anda]'}

Terima kasih`;
};
