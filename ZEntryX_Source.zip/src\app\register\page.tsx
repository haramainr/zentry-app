"use client";

import { useState, useRef, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import SignatureCanvas from 'react-signature-canvas';
import { createClient } from "@/lib/supabase/client";

export default function RegisterPage() {
  const router = useRouter();
  const supabase = createClient();
  const sigCanvas = useRef<SignatureCanvas>(null);
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    role: 'Sales',
    supervisor_id: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [leaders, setLeaders] = useState<{id: string, full_name: string}[]>([]);

  useEffect(() => {
    const fetchLeaders = async () => {
      const { data } = await supabase.from('users').select('id, full_name').eq('role', 'Leader');
      if (data) setLeaders(data);
    };
    fetchLeaders();
  }, []);

  const needsSignature = formData.role === 'Sales' || formData.role === 'Leader';

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // 1. Validasi Tanda Tangan
      if (needsSignature && sigCanvas.current?.isEmpty()) {
        throw new Error("Tanda Tangan wajib diisi untuk role Sales dan Leader.");
      }

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            full_name: formData.fullName,
            role: formData.role,
            ...(formData.role === 'Sales' && formData.supervisor_id ? { supervisor_id: formData.supervisor_id } : {})
          }
        }
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error("Pendaftaran gagal. Email mungkin sudah terdaftar atau sistem menolak registrasi Anda.");

      // Update email to public.users table just in case the database trigger doesn't do it
      if (authData.user) {
        await supabase.from('users').update({ email: formData.email }).eq('id', authData.user.id);
      }

      // 3. Simpan Tanda Tangan jika ada (Simpan langsung Base64 ke database agar lebih aman dan cepat)
      if (authData.user && needsSignature && sigCanvas.current) {
        const signatureBase64 = sigCanvas.current.toDataURL(); // Ini berupa "data:image/png;base64,..."
        
        const { error: dbError } = await supabase.from('signatures').insert({
          user_id: authData.user.id,
          signature_url: signatureBase64 // Kita simpan data Base64-nya secara utuh
        });

        if (dbError) {
          throw new Error("Gagal menyimpan tanda tangan ke database: " + dbError.message);
        }
      }

      alert("Registrasi Berhasil! Anda sekarang masuk ke dalam sistem.");
      
      // Arahkan ke dashboard sesuai role
      if (formData.role === 'Sales') router.push('/sales/form');
      else router.push('/'); // Placeholder untuk dashboard lain

    } catch (err: any) {
      console.error("REGISTER ERROR:", err);
      let errorMsg = "Terjadi kesalahan saat registrasi.";
      
      try {
        // Coba ekstrak error Supabase (AuthError biasanya punya .message, .status, .name)
        if (err?.message) {
          errorMsg = `${err.name ? err.name + ': ' : ''}${err.message} ${err.status ? '(Status: ' + err.status + ')' : ''}`;
        } else {
          errorMsg = JSON.stringify(err, Object.getOwnPropertyNames(err));
        }
      } catch(e) {
        errorMsg = String(err);
      }

      const cleanMsg = errorMsg.replace(/\s+/g, '');
      if (cleanMsg === '{}' || cleanMsg === '""' || cleanMsg === "''") {
        errorMsg = "Sistem menolak registrasi tanpa pesan error yang jelas (Bisa karena email sudah ada atau trigger database gagal).";
      }

      setError(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`
        }
      });
      if (error) throw error;
    } catch (err: any) {
      setError(err.message || "Gagal login dengan Google");
    }
  };

  return (
    <div className="flex items-center justify-center" style={{ minHeight: '100vh', backgroundColor: 'var(--bg-color)', padding: 'var(--spacing-lg)' }}>
      <div className="card" style={{ maxWidth: '500px', width: '100%' }}>
        <div style={{ marginBottom: 'var(--spacing-xl)', display: 'flex', justifyContent: 'center' }}>
          <Image src="/zentry-logo.png" alt="ZEntry Logo" width={100} height={100} priority style={{ objectFit: 'contain' }} />
        </div>
        
        <div style={{ textAlign: 'center', marginBottom: 'var(--spacing-xl)' }}>
          <h1 className="h2" style={{ marginBottom: 'var(--spacing-sm)' }}>Pendaftaran ZEntry</h1>
          <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
            Buat akun untuk mengakses sistem manajemen ZEntry.
          </p>
        </div>

        {error && (
          <div style={{ backgroundColor: '#ffebee', color: '#c62828', padding: '10px', borderRadius: '4px', marginBottom: '16px', fontSize: '14px' }}>
            {error}
          </div>
        )}
        
        <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-md)' }}>
          
          <div className="input-group">
            <label className="input-label">Nama Lengkap</label>
            <input type="text" name="fullName" required className="input-field" value={formData.fullName} onChange={handleChange} />
          </div>

          <div className="input-group">
            <label className="input-label">Email Institusi</label>
            <input type="email" name="email" required className="input-field" value={formData.email} onChange={handleChange} />
          </div>

          <div className="input-group">
            <label className="input-label">Password</label>
            <div style={{ position: 'relative' }}>
              <input type={showPassword ? "text" : "password"} name="password" required className="input-field" value={formData.password} onChange={handleChange} style={{ paddingRight: '60px' }} />
              <button type="button" onClick={() => setShowPassword(!showPassword)} style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--solasi-blue)', fontSize: '13px', fontWeight: 600 }}>
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </div>

          <div className="input-group" style={{ textAlign: 'left' }}>
            <label className="input-label">Mendaftar Sebagai (Jabatan)</label>
            <select name="role" required className="input-field" value={formData.role} onChange={handleChange} style={{ appearance: 'none', backgroundColor: '#fff' }}>
              <option value="Sales">Sales</option>
              <option value="Leader">Leader</option>
              <option value="Manager">Manager</option>
            </select>
          </div>

          {formData.role === 'Sales' && (
            <div className="input-group">
              <label className="input-label">Pilih Supervisor / Leader Anda</label>
              <select name="supervisor_id" required className="input-field" value={formData.supervisor_id} onChange={handleChange}>
                <option value="">-- Pilih Leader --</option>
                {leaders.map(leader => (
                  <option key={leader.id} value={leader.id}>{leader.full_name}</option>
                ))}
              </select>
              {leaders.length === 0 && <span className="text-small" style={{ color: 'red', marginTop: '4px' }}>Belum ada Leader yang terdaftar. Leader harus mendaftar duluan.</span>}
            </div>
          )}

          {needsSignature && (
            <div className="input-group" style={{ marginTop: 'var(--spacing-md)' }}>
              <label className="input-label">Tanda Tangan Digital (Wajib)</label>
              <p className="text-small" style={{ marginBottom: '8px', color: 'var(--text-muted)' }}>
                Tanda tangan ini akan disimpan di brankas digital Anda dan akan otomatis digunakan pada setiap formulir PDF yang Anda buat.
              </p>
              <div style={{ border: '2px dashed var(--border-color)', borderRadius: 'var(--radius-lg)', backgroundColor: 'var(--surface-color)', overflow: 'hidden' }}>
                <SignatureCanvas 
                  ref={sigCanvas}
                  canvasProps={{
                    className: 'signature-canvas',
                    style: { width: '100%', height: '150px', cursor: 'crosshair', touchAction: 'none' }
                  }} 
                />
              </div>
              <div className="flex justify-end" style={{ marginTop: '8px' }}>
                <button type="button" className="btn" style={{ padding: '4px 8px', fontSize: '12px', border: '1px solid var(--border-color)' }} onClick={() => sigCanvas.current?.clear()}>
                  Bersihkan Tanda Tangan
                </button>
              </div>
            </div>
          )}

          <button type="submit" disabled={loading} className="btn btn-primary" style={{ marginTop: 'var(--spacing-md)' }}>
            {loading ? "Memproses..." : "Daftar Akun"}
          </button>
          
          <div style={{ textAlign: 'center', margin: 'var(--spacing-sm) 0', color: 'var(--text-muted)', fontSize: '0.9rem' }}>Atau</div>
            
          <button type="button" onClick={handleGoogleLogin} disabled={loading} className="btn btn-outline" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            Masuk dengan Google
          </button>
        </form>

        <p className="text-small" style={{ marginTop: 'var(--spacing-xl)', textAlign: 'center', color: 'var(--text-muted)' }}>
          Sudah punya akun? <Link href="/login" style={{ color: 'var(--solasi-blue)', textDecoration: 'underline' }}>Login di sini</Link>
        </p>
      </div>
    </div>
  );
}
