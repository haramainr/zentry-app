import { NextRequest, NextResponse } from 'next/server';
import { PDFDocument, StandardFonts, TextAlignment } from 'pdf-lib';
import fs from 'fs';
import path from 'path';
import { createClient } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  try {
    const data = await req.json();
    
    // Fetch user signature from Supabase Vault
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (user) {
      // parse numeric values
      const parseRp = (str: string) => {
        if (!str) return 0;
        return Number(str.replace(/[^0-9]/g, ''));
      };

      const dbPayload = {
        sales_id: user.id,
        nama_lengkap: data.namaLengkap || '',
        tempat_lahir: data.tempatLahir || null,
        tanggal_lahir: data.tanggalLahir || null,
        ktp: data.ktp || '',
        jenis_kelamin: data.jenisKelamin || null,
        telp_selular: data.telpSelular || '',
        telp_rumah: data.telpRumah || null,
        alamat: data.alamat || '',
        rt: data.rt || null,
        rw: data.rw || null,
        kode_pos: data.kodePos || null,
        status_kepemilikan: data.statusKepemilikan || null,
        email: data.email || '',
        paket_layanan: data.paketLayanan || '',
        paket_spec: data.paketLayanan === 'Fiber' ? data.paketFiberSpec : data.paketLayanan === 'Safe' ? data.paketSafeSpec : data.paketProSpec || null,
        router_qty: Number(data.routerQty) || 0,
        smartbox_qty: Number(data.smartboxQty) || 0,
        username_zentry: data.username || null,
        tgl_pemasangan: data.tglPemasangan || null,
        waktu_pemasangan: data.waktuPemasangan || null,
        catatan: data.catatan || null,
        cc_nama: data.ccNama || null,
        cc_nomor: data.ccNomor || null,
        cc_berlaku: data.ccBerlaku || null,
        cc_bank: data.ccBank || null,
        cc_wewenang: data.ccWewenang || false,
        signature_base64: data.signature || null,
        cc_signature_base64: data.ccSignature || null,
        
        vas: JSON.stringify({
          vas: data.vas,
          routerText: data.routerText,
          routerPrice: data.routerPrice,
          routerQty: data.routerQty,
          smartboxText: data.smartboxText,
          smartboxQty: data.smartboxQty,
          customText: data.customText,
          customPrice: data.customPrice,
          customQty: data.customQty,
          densTvCheck: data.densTvCheck,
          visionTvCheck: data.visionTvCheck,
          addon1Check: data.addon1Check,
          addon1Text: data.addon1Text
        }),
        promo: data.promoTerm || null,
        homepass_id: data.homepassId || null,
        titik_koordinat: data.titikKoordinat || null,

        biaya_pemasangan: parseRp(data.biayaPemasangan),
        biaya_paket: parseRp(data.biayaPaket),
        biaya_tambahan: parseRp(data.biayaTambahan),
        biaya_services: parseRp(data.biayaServices),
        biaya_addons: parseRp(data.biayaAddons),
        biaya_perangkat: parseRp(data.biayaPerangkat),
        biaya_lainnya: parseRp(data.biayaLainnya),
        biaya_ppn: parseRp(data.biayaPpn),
        biaya_total: parseRp(data.biayaTotal),
        is_draft: false,
        status_pemasangan: 'Pending',
        updated_at: new Date().toISOString()
      };

      if (data.id) {
        // Update existing draft
        await supabase.from('submissions').update(dbPayload).eq('id', data.id);
      } else {
        // Insert new submission
        await supabase.from('submissions').insert([dbPayload]);
      }
    }
    
    let salesSignatureBase64 = null;
    let leaderSignatureBase64 = null;
    let salesFullName = '';
    let leaderFullName = '';

    if (user) {
      // 1. Ambil Signature Sales
      const { data: salesSigData } = await supabase.from('signatures').select('signature_url').eq('user_id', user.id).maybeSingle();
      if (salesSigData && salesSigData.signature_url) {
         salesSignatureBase64 = salesSigData.signature_url.replace(/^data:image\/\w+;base64,/, "");
      }

      // 2. Ambil Supervisor ID & Full Name dari profil Sales
      const { data: profile } = await supabase.from('users').select('full_name, supervisor_id').eq('id', user.id).maybeSingle();
      if (profile) salesFullName = profile.full_name;
      
      // 3. Ambil Signature Supervisor
      if (profile && profile.supervisor_id) {
        const { data: leaderProfile } = await supabase.from('users').select('full_name').eq('id', profile.supervisor_id).maybeSingle();
        if (leaderProfile) leaderFullName = leaderProfile.full_name;

        const { data: leaderSigData } = await supabase.from('signatures').select('signature_url').eq('user_id', profile.supervisor_id).maybeSingle();
        if (leaderSigData && leaderSigData.signature_url) {
           leaderSignatureBase64 = leaderSigData.signature_url.replace(/^data:image\/\w+;base64,/, "");
        }
      }
    }

    const templatePath = path.join(process.cwd(), 'public', 'templates', 'cbn-form-template.pdf');
    const existingPdfBytes = fs.readFileSync(templatePath);
    const pdfDoc = await PDFDocument.load(existingPdfBytes);
    
    // Embed font agar bisa resize ukuran dengan akurat
    const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const helveticaBoldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    const form = pdfDoc.getForm();
    const pages = pdfDoc.getPages();
    const firstPage = pages[0];

    const fillText = (fieldName: string, value: string, fontSize?: number) => {
      if (!value) return;
      try { 
        const field = form.getTextField(fieldName);
        field.setText(value); 
        
        if (fontSize) {
          field.setFontSize(fontSize);
          // Wajib panggil update agar font yang dikecilkan langsung di-render
          field.defaultUpdateAppearances(helveticaFont);
        }
      } catch (e) {}
    };

    const fillSignatureName = (fieldName: string, value: string, fontSize: number = 7) => {
      if (!value) return;
      try {
        const field = form.getTextField(fieldName);
        field.setText(value);
        field.setAlignment(TextAlignment.Center);
        field.setFontSize(fontSize);
        field.defaultUpdateAppearances(helveticaBoldFont);
      } catch (e) {}
    };

    const checkBox = (fieldName: string, check: boolean) => {
      if (!check) return;
      try { form.getCheckBox(fieldName).check(); } catch (e) {}
    };

    // 1. Data Pelanggan
    fillText('Text1', data.namaLengkap);
    fillText('Text7', data.tempatLahir);
    
    if (data.tanggalLahir) {
      const parts = data.tanggalLahir.split('-'); 
      if (parts.length === 3) {
        fillText('Text12', parts[2]); // DD
        fillText('Text13', parts[1]); // MM
        fillText('Text14', parts[0]); // YYYY
      }
    }

    checkBox('Button5', data.jenisKelamin === 'Pria');
    checkBox('Button6', data.jenisKelamin === 'Wanita');

    fillText('Text9', data.ktp);
    fillText('Text11', data.telpRumah);
    fillText('Text10', data.telpSelular);

    // 2. Alamat Pemasangan
    fillText('Text16', data.alamat);
    fillText('Text43', data.rt);
    fillText('Text44', data.rw);
    fillText('Text25', data.kodePos);
    
    checkBox('Button26', data.statusKepemilikan === 'Pemilik');
    checkBox('Button27', data.statusKepemilikan === 'Penyewa');
    
    fillText('Text15', data.email);

    // 3. Paket Layanan & Perangkat
    const formatPaketText = (spec: string, area: string, promo: string) => {
      let text = spec || '';
      if (area && area !== 'Regular FS') {
        text += ` | Servis: ${area}`;
      }
      if (promo && promo !== 'Bulanan (Regular)') {
        text += ` | Promo Khusus: ${promo}`;
      }
      return text;
    };

    checkBox('Button28', data.paketLayanan === 'Fiber');
    if (data.paketLayanan === 'Fiber') fillText('Text3', formatPaketText(data.paketSpec, data.area, data.promoTerm), 6);
    
    checkBox('Button29', data.paketLayanan === 'Safe');
    if (data.paketLayanan === 'Safe') fillText('Text4', formatPaketText(data.paketSpec, data.area, data.promoTerm), 6);
    
    checkBox('Button30', data.paketLayanan === 'Pro');
    if (data.paketLayanan === 'Pro') fillText('Text5', formatPaketText(data.paketSpec, data.area, data.promoTerm), 6);

    const getDynamicFontSize = (text: string) => {
      if (!text) return 7;
      if (text.length > 50) return 4;
      if (text.length > 35) return 5;
      if (text.length > 25) return 6;
      return 7;
    };

    if (data.routerQty || data.routerText) {
      checkBox('Button31', true);
      if (data.routerQty) fillText('Text46', data.routerQty.toString());
      if (data.routerText) fillText('Text41', data.routerText, getDynamicFontSize(data.routerText));
    }
    if (data.smartboxQty || data.smartboxText) {
      checkBox('Button32', true);
      if (data.smartboxQty) fillText('Text47', data.smartboxQty.toString());
      if (data.smartboxText) fillText('Text42', data.smartboxText, getDynamicFontSize(data.smartboxText));
    }
    if (data.customQty || data.customText) {
      checkBox('Button33', true);
      if (data.customText) fillText('Text48', data.customText, getDynamicFontSize(data.customText));
    }
    
    // Paket Add-On TV (Custom / Checkbox)
    if (data.densTvCheck) checkBox('Button37', true);
    if (data.visionTvCheck) checkBox('Button38', true);

    // Custom Add-On TV (Lainnya) -> Left Side (Button51 & Text53)
    if (data.addon1Check || data.addon1Text) {
      if (data.addon1Check) checkBox('Button51', true);
      if (data.addon1Text) fillText('Text53', data.addon1Text, getDynamicFontSize(data.addon1Text));
    }

    // VAS Mapping -> Right Side (3 Slots)
    let vasArray: string[] = [];
    if (data.vas && Array.isArray(data.vas)) {
      vasArray = data.vas;
    } else if (typeof data.vas === 'string' && data.vas.trim() !== '') {
      vasArray = [data.vas];
    }

    if (vasArray.length > 0) {
      checkBox('Button49', true);
      fillText('Text51', vasArray[0], getDynamicFontSize(vasArray[0]));
    }
    if (vasArray.length > 1) {
      checkBox('Button50', true);
      fillText('Text52', vasArray[1], getDynamicFontSize(vasArray[1]));
    }
    if (vasArray.length > 2) {
      checkBox('Button1', true);
      // Jika lebih dari 3, gabungkan sisanya di slot ke-3
      const remaining = vasArray.slice(2).join(', ');
      fillText('Text49', remaining, getDynamicFontSize(remaining));
    }

    // 4. Aktivasi, Jadwal & Catatan
    fillText('Text17', data.username);
    fillText('Text21', data.hariPemasangan); 

    if (data.tglPemasangan) {
      const parts = data.tglPemasangan.split('-');
      if (parts.length === 3) {
        fillText('Text23', parts[2]); 
        fillText('Text24', parts[1]); 
        fillText('Text45', parts[0]); 
      }
    }

    checkBox('Button39', data.waktuPemasangan === '09.00-11.00');
    checkBox('Button40', data.waktuPemasangan === '11.00-13.00');
    checkBox('Button41', data.waktuPemasangan === '13.00-15.00');
    checkBox('Button42', data.waktuPemasangan === '15.00-17.00');

    fillText('Text8', data.catatan, 6); 

    // 5. Pembayaran Via Kartu Kredit (Ubah font ke 6 agar super pas!)
    fillText('Text35', data.ccNama, 6);
    fillText('Text36', data.ccNomor, 6);
    fillText('Text38', data.ccBerlaku, 6);
    fillText('Text37', data.ccBank, 6);
    checkBox('Button43', data.ccWewenang);

    // 6. Rincian Biaya
    fillText('Text26', data.biayaPemasangan, 8);
    fillText('Text27', data.biayaPaket, 8);
    fillText('Text28', data.biayaTambahan, 8);
    fillText('Text29', data.biayaServices, 8);
    fillText('Text30', data.biayaAddons, 8);
    fillText('Text31', data.biayaPerangkat, 8);
    fillText('Text32', data.biayaLainnya, 8);
    fillText('Text33', data.biayaPpn, 8);
    fillText('Text22', data.biayaTotal, 11); // TOTAL TETAP BESAR

    const today = new Date();
    const formattedDate = `${today.getDate().toString().padStart(2, '0')}/${(today.getMonth() + 1).toString().padStart(2, '0')}/${today.getFullYear()}`;
    fillText('Text2', formattedDate, 8);

    // =========================================================================
    // KOORDINAT KOTAK TANDA TANGAN 
    // =========================================================================
    let sigBoxRect: any = null;
    try {
      const sigField = form.getTextField('Text18');
      const widgets = sigField.acroField.getWidgets();
      if(widgets.length > 0) sigBoxRect = widgets[0].getRectangle();
    } catch(e) {}

    let ccSigBoxRect: any = null;
    try {
      const ccSigField = form.getTextField('Text34'); 
      const widgets = ccSigField.acroField.getWidgets();
      if(widgets.length > 0) ccSigBoxRect = widgets[0].getRectangle();
    } catch(e) {}

    let salesSigBoxRect: any = null;
    try {
      const salesSigField = form.getTextField('Text19'); 
      const widgets = salesSigField.acroField.getWidgets();
      if(widgets.length > 0) salesSigBoxRect = widgets[0].getRectangle();
    } catch(e) {}

    let leaderSigBoxRect: any = null;
    try {
      const leaderSigField = form.getTextField('Text20'); 
      const widgets = leaderSigField.acroField.getWidgets();
      if(widgets.length > 0) leaderSigBoxRect = widgets[0].getRectangle();
    } catch(e) {}

    // =========================================================================
    // NAMA DI BAWAH TANDA TANGAN (MENGGUNAKAN BOX BARU)
    // =========================================================================
    fillSignatureName('Text6', data.namaLengkap, 5);
    fillSignatureName('Text39', salesFullName, 5);
    fillSignatureName('Text40', leaderFullName, 5);

    // Flatten form sebelum menggambar tanda tangan (ini yang akan apply semua appearance)
    form.flatten();

    // =========================================================================
    // MENGGAMBAR TANDA TANGAN 
    // =========================================================================
    if (data.signature) {
      try {
        const base64Data = data.signature.replace(/^data:image\/png;base64,/, "");
        const pngImage = await pdfDoc.embedPng(Buffer.from(base64Data, 'base64'));
        
        if (sigBoxRect) {
          const imgDims = pngImage.scale(1);
          const scaleX = sigBoxRect.width / imgDims.width;
          const scaleY = sigBoxRect.height / imgDims.height;
          const scaleToFit = Math.min(scaleX, scaleY); 
          
          const finalWidth = imgDims.width * scaleToFit;
          const finalHeight = imgDims.height * scaleToFit;
          
          const centerX = sigBoxRect.x + (sigBoxRect.width - finalWidth) / 2;
          const centerY = sigBoxRect.y + (sigBoxRect.height - finalHeight) / 2;

          firstPage.drawImage(pngImage, { 
            x: centerX, 
            y: centerY, 
            width: finalWidth, 
            height: finalHeight 
          });
        }
      } catch (e) {
        console.error("Gagal menggambar tanda tangan pelanggan", e);
      }
    }

    if (data.ccSignature) {
      try {
        const base64Data = data.ccSignature.replace(/^data:image\/png;base64,/, "");
        const pngImage = await pdfDoc.embedPng(Buffer.from(base64Data, 'base64'));
        
        if (ccSigBoxRect) {
          const imgDims = pngImage.scale(1);
          const scaleX = ccSigBoxRect.width / imgDims.width;
          const scaleY = ccSigBoxRect.height / imgDims.height;
          const scaleToFit = Math.min(scaleX, scaleY); 
          
          const finalWidth = imgDims.width * scaleToFit;
          const finalHeight = imgDims.height * scaleToFit;
          
          const centerX = ccSigBoxRect.x + (ccSigBoxRect.width - finalWidth) / 2;
          const centerY = ccSigBoxRect.y + (ccSigBoxRect.height - finalHeight) / 2;

          firstPage.drawImage(pngImage, { 
            x: centerX, 
            y: centerY, 
            width: finalWidth, 
            height: finalHeight 
          });
        } else {
          // Fallback manual 
          const pngDims = pngImage.scale(0.3); // agak besar sedikit
          firstPage.drawImage(pngImage, { 
            x: 160, 
            y: 283, 
            width: pngDims.width, 
            height: pngDims.height 
          });
        }
      } catch (e) {
        console.error("Gagal menggambar tanda tangan CC", e);
      }
    }

    // Menggambar Tanda Tangan Sales dari Vault
    if (salesSignatureBase64) {
      try {
        const pngImage = await pdfDoc.embedPng(Buffer.from(salesSignatureBase64, 'base64'));
        if (salesSigBoxRect) {
          const imgDims = pngImage.scale(1);
          const scaleX = salesSigBoxRect.width / imgDims.width;
          const scaleY = salesSigBoxRect.height / imgDims.height;
          const scaleToFit = Math.min(scaleX, scaleY); 
          const finalWidth = imgDims.width * scaleToFit;
          const finalHeight = imgDims.height * scaleToFit;
          const centerX = salesSigBoxRect.x + (salesSigBoxRect.width - finalWidth) / 2;
          const centerY = salesSigBoxRect.y + (salesSigBoxRect.height - finalHeight) / 2;
          firstPage.drawImage(pngImage, { x: centerX, y: centerY, width: finalWidth, height: finalHeight });
        }
      } catch (e) {
        console.error("Gagal menggambar tanda tangan Sales", e);
      }
    }

    // Menggambar Tanda Tangan Leader/Supervisor dari Vault
    if (leaderSignatureBase64) {
      try {
        const pngImage = await pdfDoc.embedPng(Buffer.from(leaderSignatureBase64, 'base64'));
        if (leaderSigBoxRect) {
          const imgDims = pngImage.scale(1);
          const scaleX = leaderSigBoxRect.width / imgDims.width;
          const scaleY = leaderSigBoxRect.height / imgDims.height;
          const scaleToFit = Math.min(scaleX, scaleY); 
          const finalWidth = imgDims.width * scaleToFit;
          const finalHeight = imgDims.height * scaleToFit;
          const centerX = leaderSigBoxRect.x + (leaderSigBoxRect.width - finalWidth) / 2;
          const centerY = leaderSigBoxRect.y + (leaderSigBoxRect.height - finalHeight) / 2;
          firstPage.drawImage(pngImage, { x: centerX, y: centerY, width: finalWidth, height: finalHeight });
        }
      } catch (e) {
        console.error("Gagal menggambar tanda tangan Leader", e);
      }
    }
    
    const pdfBytes = await pdfDoc.save();

    // Workaround for TypeScript error: Cast to 'any' or 'unknown as BodyInit'
    return new NextResponse(pdfBytes as any, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': 'attachment; filename="form_pendaftaran_filled.pdf"',
      },
    });
  } catch (error: any) {
    console.error('Error generating PDF:', error);
    return NextResponse.json({ error: 'Failed to generate PDF', details: error.message || String(error) }, { status: 500 });
  }
}
