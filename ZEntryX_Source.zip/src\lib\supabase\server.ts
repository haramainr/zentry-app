import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
import { getDummyClient } from './dummy'

export async function createClient() {
  const cookieStore = await cookies()

  const isDummyAuth = cookieStore.get('dummy_auth')?.value === 'true' || process.env.NEXT_PUBLIC_SUPABASE_URL?.includes('placeholder')
  if (isDummyAuth) {
    const dummyRole = cookieStore.get('dummy_role')?.value || 'Manager'
    return getDummyClient(dummyRole) as any
  }

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            )
          } catch {
            // The `setAll` method was called from a Server Component.
            // This can be ignored if you have middleware refreshing
            // user sessions.
          }
        },
      },
    }
  )
}
