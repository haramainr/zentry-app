import { createBrowserClient } from '@supabase/ssr'
import { getDummyClient } from './dummy'

export function createClient() {
  if ((typeof document !== 'undefined' && document.cookie.includes('dummy_auth=true')) || process.env.NEXT_PUBLIC_SUPABASE_URL?.includes('placeholder')) {
    let role = 'Manager';
    if (typeof document !== 'undefined') {
      const roleMatch = document.cookie.match(/dummy_role=([^;]+)/);
      if (roleMatch) role = decodeURIComponent(roleMatch[1]);
    }
    return getDummyClient(role) as any;
  }

  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
