import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import SalesDashboardClient from "@/components/SalesDashboardClient";
import ExportExcelButton from "@/components/ExportExcelButton";

export const dynamic = 'force-dynamic';

export default async function SalesDashboard() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  // Ambil data profile
  const { data: profile } = await supabase
    .from("users")
    .select("full_name, role")
    .eq("id", user.id)
    .single();

  // Jika nyasar ke halaman sales tapi rolenya bukan sales, kembalikan ke tempat yang benar
  if (profile?.role === 'Developer') {
    redirect("/developer");
  } else if (profile?.role === 'Manager' || profile?.role === 'Admin') {
    redirect("/manager");
  } else if (profile?.role === 'Leader') {
    redirect("/leader");
  }

  const { data: submissions } = await supabase
    .from("submissions")
    .select("id, status_pemasangan, biaya_total, created_at, paket_layanan, paket_spec, promo, is_draft, nama_lengkap")
    .eq("sales_id", user.id)
    .order('created_at', { ascending: false });

  const sentSubmissions = submissions?.filter(s => !s.is_draft) || [];
  const draftSubmissions = submissions?.filter(s => s.is_draft) || [];

  const stats = {
    totalRegistrations: sentSubmissions.length,
    drafts: draftSubmissions.length,
    totalRevenue: sentSubmissions.reduce((sum, current) => sum + Number(current.biaya_total || 0), 0),
  };

  const usersList = [
    { id: user.id, full_name: profile?.full_name || '', role: 'Sales', supervisor_id: null }
  ];

  return (
    <div className="animate-fade-in" style={{ padding: '32px', backgroundColor: '#F8FAFC', minHeight: '100vh' }}>
      <header style={{ marginBottom: '32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h1 style={{ fontSize: '1.75rem', fontWeight: 800, color: '#0F172A', margin: 0 }}>Selamat Datang, {profile?.full_name || 'Sales zyntaxera'} 👋</h1>
          <p style={{ fontSize: '0.95rem', color: '#64748B', margin: 0, marginTop: '4px' }}>Ringkasan performa penjualan Anda hari ini.</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
          {/* Date Range Badge */}
          <div style={{ background: '#FFFFFF', border: '1px solid #E2E8F0', padding: '8px 16px', borderRadius: '12px', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.85rem', fontWeight: 600, color: '#334155', boxShadow: '0 1px 2px rgba(0,0,0,0.03)' }}>
            <span style={{ fontSize: '1rem' }}>📅</span> 30/06/2026 - 25/07/2026 <span style={{ fontSize: '0.7rem', color: '#94A3B8' }}>⌄</span>
          </div>

          <ExportExcelButton role="Sales" currentUserId={user.id} usersList={usersList} />

          {/* Profile Badge & Notification */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', background: '#FFFFFF', border: '1px solid #E2E8F0', padding: '6px 14px 6px 6px', borderRadius: '30px', boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
            <div style={{ width: '38px', height: '38px', borderRadius: '50%', background: '#0F172A', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '0.95rem' }}>
              {(profile?.full_name || 'S').charAt(0).toUpperCase()}
            </div>
            <div>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#0F172A', lineHeight: 1.1 }}>{profile?.full_name || 'Sales zyntaxera'} <span style={{ fontSize: '0.7rem', color: '#94A3B8' }}>⌄</span></div>
              <div style={{ fontSize: '0.7rem', color: '#64748B', fontWeight: 500 }}>Sales Team</div>
            </div>
            <div style={{ position: 'relative', marginLeft: '6px', paddingLeft: '12px', borderLeft: '1px solid #F1F5F9', cursor: 'pointer' }}>
              <span style={{ fontSize: '1.2rem' }}>🔔</span>
              <span style={{ position: 'absolute', top: '-4px', right: '-6px', background: '#2563EB', color: 'white', fontSize: '0.65rem', fontWeight: 700, width: '18px', height: '18px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid white' }}>2</span>
            </div>
          </div>
        </div>
      </header>

      {/* Interactive Dashboard Content */}
      <SalesDashboardClient submissions={submissions || []} />
    </div>
  );
}
