import Tesseract from 'tesseract.js';

// Fungsi untuk meningkatkan kualitas gambar sebelum di-OCR (Grayscale & Contrast)
const preprocessImage = async (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      // Batasi ukuran maksimal agar tidak berat, tapi cukup besar untuk detail
      const scale = Math.min(2500 / Math.max(img.width, img.height), 1); 
      canvas.width = img.width * scale;
      canvas.height = img.height * scale;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject('No canvas context');
      
      // Gambar dengan filter grayscale dan contrast langsung di canvas context jika didukung
      ctx.filter = 'grayscale(100%) contrast(150%) brightness(110%)';
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      
      resolve(canvas.toDataURL('image/jpeg', 1.0));
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
};

export const parseKtpOcr = async (imageFile: File) => {
  try {
    const processedImageDataUrl = await preprocessImage(imageFile);
    
    // Gunakan Tesseract dengan gambar yang sudah difilter
    const result = await Tesseract.recognize(processedImageDataUrl, 'ind', {
      logger: m => console.log(m)
    });
    
    const text = result.data.text;
    
    const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    
    let nik = '';
    let nama = '';
    let tempatLahir = '';
    let tglLahir = '';
    let jenisKelamin = '';
    
    // Trik: Tesseract sering salah baca angka jadi huruf. 
    // Kita buat salinan teks khusus untuk mendeteksi angka (NIK & Tanggal)
    const textForNumbers = text.toUpperCase()
      .replace(/[OQ]/g, '0')
      .replace(/[IlL|]/g, '1')
      .replace(/Z/g, '2')
      .replace(/S/g, '5')
      .replace(/G/g, '6')
      .replace(/T/g, '7')
      .replace(/B/g, '8')
      .replace(/e/gi, '8')
      .replace(/A/g, '4');

    // Cari NIK (16 digit) dengan mengabaikan spasi
    const textNoSpaces = textForNumbers.replace(/\s+/g, '');
    const nikMatch = textNoSpaces.match(/\d{16}/);
    if (nikMatch) {
      nik = nikMatch[0];
    }
    
    // Cari Tanggal Lahir (DD-MM-YYYY) di mana pun di dalam teks
    const dateMatch = textForNumbers.match(/\b(\d{2})[-/ ](\d{2})[-/ ](\d{4})\b/);
    if (dateMatch) {
      tglLahir = `${dateMatch[3]}-${dateMatch[2]}-${dateMatch[1]}`; // YYYY-MM-DD
    }

    // Identifikasi baris NIK untuk heuristik posisi
    let nikLineIndex = -1;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].toUpperCase().replace(/\s+/g, '').replace(/[OQ]/g, '0').replace(/[IlL|]/g, '1').match(/\d{16}/)) {
        nikLineIndex = i;
        break;
      }
    }

    // Fungsi pembersih teks label (seperti "Nama : " atau "Tempat/Tgl Lahir : ")
    const cleanLabel = (text: string, labelRegex: RegExp) => {
      let val = text;
      if (val.includes(':')) {
        val = val.split(':').slice(1).join(':').trim(); // Ambil semua setelah titik dua pertama
      } else {
        val = val.replace(labelRegex, '').trim(); // Buang kata labelnya
      }
      return val.replace(/[^a-zA-Z\s.-]/g, '').trim().toUpperCase(); // Bersihkan simbol aneh
    };

    // Parsing baris per baris untuk teks lainnya
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].toLowerCase();
      const rawLine = lines[i];

      // Parsing Nama
      // Kita pakai regex yang bisa menangkap "N A M A" atau "Nam a"
      const namaRegex = /^.*?(n\s*a\s*m\s*a)\s*[:;]?\s*/i;
      if ((namaRegex.test(rawLine) || line.includes('nama')) && !line.includes('kewarganegaraan') && !nama) {
        let val = cleanLabel(rawLine, namaRegex);
        if ((!val || val.length < 3) && i + 1 < lines.length) {
          val = cleanLabel(lines[i + 1], namaRegex);
        }
        if (val) nama = val;
      }
      
      // Parsing Tempat Lahir
      const tempatRegex = /^.*?(t\s*e\s*m\s*p\s*a\s*t|l\s*a\s*h\s*i\s*r)\s*[:;]?\s*/i;
      if ((tempatRegex.test(rawLine) || line.includes('tempat') || line.includes('lahir')) && !tempatLahir) {
        let ttl = rawLine;
        if (ttl.includes(':')) {
          ttl = ttl.split(':').slice(1).join(':').trim();
        } else {
          ttl = ttl.replace(tempatRegex, '').trim();
        }
        
        if ((!ttl || ttl.length < 3) && i + 1 < lines.length) {
          ttl = lines[i + 1].trim();
        }
        
        const parts = ttl.split(',');
        if (parts.length > 0) {
          tempatLahir = parts[0].replace(/[^a-zA-Z\s]/g, '').trim().toUpperCase();
        }
      }
      
      // Parsing Jenis Kelamin
      if (line.includes('kelamin') && !jenisKelamin) {
        if (line.includes('laki') || line.includes('pria')) jenisKelamin = 'Pria';
        else if (line.includes('perempuan') || line.includes('wanita') || line.includes('puan')) jenisKelamin = 'Wanita';
        
        if (!jenisKelamin) {
          const val = rawLine.split(':').pop()?.toLowerCase() || '';
          if (val.includes('laki') || val.includes('pria')) jenisKelamin = 'Pria';
          else if (val.includes('perempuan') || val.includes('wanita') || val.includes('puan')) jenisKelamin = 'Wanita';
        }
      }
    }

    // Fallback Heuristik Posisi (Jika regex label gagal sama sekali)
    // Di KTP, biasanya: Baris NIK -> Baris Nama -> Baris Tempat/Tgl Lahir
    if (nikLineIndex !== -1) {
      if (!nama && nikLineIndex + 1 < lines.length) {
        nama = cleanLabel(lines[nikLineIndex + 1], /^.*?(n\s*a\s*m\s*a)\s*[:;]?\s*/i);
      }
      if (!tempatLahir && nikLineIndex + 2 < lines.length) {
        let ttl = cleanLabel(lines[nikLineIndex + 2], /^.*?(t\s*e\s*m\s*p\s*a\s*t|l\s*a\s*h\s*i\s*r)\s*[:;]?\s*/i);
        const parts = ttl.split(',');
        if (parts.length > 0) {
          tempatLahir = parts[0].replace(/[^a-zA-Z\s]/g, '').trim().toUpperCase();
        }
      }
    }
    
    return {
      nik,
      nama,
      tempatLahir,
      tglLahir,
      jenisKelamin
    };
  } catch (error) {
    console.error("OCR Error:", error);
    return null;
  }
};
